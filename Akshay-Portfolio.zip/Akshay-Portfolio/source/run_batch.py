import sys, os, json, time
sys.path.insert(0, '/home/claude/upscale')
import numpy as np
from PIL import Image
from esrgan_np import SRVGG

SRC = '/home/claude/portfolio'
OUT = '/home/claude/upscale/out'
os.makedirs(f'{OUT}/crops', exist_ok=True); os.makedirs(f'{OUT}/pages', exist_ok=True)
m = SRVGG('/home/claude/upscale/realesr-general-x4v3.pth')
manifest = json.load(open(f'{SRC}/src/data/manifest.json'))
jobs = [('crops', n) for n in manifest] + [('pages', f'page-{i:02d}') for i in range(1, 17)]
only = sys.argv[1] if len(sys.argv) > 1 else None
t0 = time.time()
for kind, n in jobs:
    if only and kind != only: continue
    dst = f'{OUT}/{kind}/{n}.jpg'
    if os.path.exists(dst): continue
    src = f'{SRC}/public/work/crops/{n}.jpg' if kind == 'crops' else f'{SRC}/public/pages/{n}.jpg'
    im = Image.open(src).convert('RGB')
    t = time.time()
    sr = Image.fromarray(m.upscale(np.array(im), tile=360))
    if kind == 'pages':   # 1920x1080 -> 3840x2160 (true 4K): downscale the 4x result for clean edges
        sr = sr.resize((3840, 2160), Image.LANCZOS)
    sr.save(dst, quality=92, subsampling=0, optimize=True)
    print(f'{kind}/{n}: {im.size} -> {sr.size}  {time.time()-t:.0f}s  (elapsed {time.time()-t0:.0f}s)', flush=True)
print('DONE', flush=True)
