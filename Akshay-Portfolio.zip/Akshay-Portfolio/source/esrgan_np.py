"""Real-ESRGAN `realesr-general-x4v3` (SRVGGNetCompact) in pure numpy — no PyTorch needed.
Loads the official .pth weights by parsing the PyTorch zip/pickle directly.
"""
import pickle, zipfile
import numpy as np

_DT = {'FloatStorage': np.float32, 'HalfStorage': np.float16, 'DoubleStorage': np.float64, 'LongStorage': np.int64}


class _Storage:
    def __init__(self, arr): self.arr = arr


def load_pth(path):
    z = zipfile.ZipFile(path)
    pkl = [n for n in z.namelist() if n.endswith('data.pkl')][0]
    root = pkl[: -len('data.pkl')]

    def rebuild(storage, offset, size, stride, *a, **k):
        n = int(np.prod(size)) if len(size) else 1
        flat = storage.arr[offset: offset + n] if not stride or len(size) == 0 else None
        if flat is None:  # contiguous in every tensor of this checkpoint
            flat = storage.arr[offset: offset + n]
        return flat.reshape(size).copy()

    class U(pickle.Unpickler):
        def find_class(self, mod, name):
            if name == '_rebuild_tensor_v2': return rebuild
            if name in _DT: return name
            if name == 'OrderedDict': import collections; return collections.OrderedDict
            if mod.startswith('torch') : return lambda *a, **k: None
            return super().find_class(mod, name)

        def persistent_load(self, pid):
            _, stype, key, _loc, numel = pid
            raw = z.read(f'{root}data/{key}')
            return _Storage(np.frombuffer(raw, dtype=_DT[stype] if isinstance(stype, str) else np.float32)[:numel])

    obj = U(z.open(pkl)).load()
    return obj.get('params', obj.get('params_ema', obj))


class SRVGG:
    def __init__(self, path, scale=4):
        sd = load_pth(path)
        self.scale = scale
        idx = sorted({int(k.split('.')[1]) for k in sd if k.startswith('body.')})
        self.layers = []
        for i in idx:
            w = sd.get(f'body.{i}.weight')
            b = sd.get(f'body.{i}.bias')
            if w is None: continue
            if w.ndim == 4:  # conv: (Cout,Cin,3,3) -> (3,3,Cin,Cout)
                self.layers.append(('conv', np.ascontiguousarray(w.transpose(2, 3, 1, 0)).astype(np.float32), b.astype(np.float32)))
            else:            # prelu
                self.layers.append(('prelu', w.astype(np.float32), None))

    @staticmethod
    def _conv(A, W, b, Hp, Wp):
        """A: (Hp*Wp, Cin) zero-padded grid, flat. Returns (Hp*Wp, Cout) (borders are garbage until re-zeroed)."""
        cout = W.shape[3]
        out = np.zeros((Hp * Wp, cout), np.float32)
        start = Wp + 1
        N = Hp * Wp - 2 * start
        acc = out[start:start + N]
        for dy in range(3):
            for dx in range(3):
                off = start + (dy - 1) * Wp + (dx - 1)
                acc += A[off:off + N] @ W[dy, dx]
        acc += b
        return out

    def _forward(self, img):  # img: (H,W,3) float32 in [0,1]
        H, W_, _ = img.shape
        Hp, Wp = H + 2, W_ + 2
        A = np.zeros((Hp, Wp, 3), np.float32)
        A[1:-1, 1:-1] = img
        A = A.reshape(Hp * Wp, 3)
        n = len(self.layers)
        for li, (kind, w, b) in enumerate(self.layers):
            if kind == 'conv':
                A = self._conv(A, w, b, Hp, Wp)
                if li == n - 1:
                    break
            else:  # PReLU, per-channel
                np.maximum(A, 0, out=A) if False else None
                neg = np.minimum(A, 0)
                A = np.maximum(A, 0) + neg * w
            if kind == 'prelu' or li < n - 1:
                A3 = A.reshape(Hp, Wp, -1)
                A3[0] = 0; A3[-1] = 0; A3[:, 0] = 0; A3[:, -1] = 0
        r = self.scale
        out = A.reshape(Hp, Wp, -1)[1:-1, 1:-1]                      # (H,W,3*r*r)
        out = out.reshape(H, W_, 3, r, r).transpose(0, 3, 1, 4, 2).reshape(H * r, W_ * r, 3)
        base = np.repeat(np.repeat(img, r, axis=0), r, axis=1)       # nearest-neighbour base
        return np.clip(out + base, 0, 1)

    def upscale(self, rgb_uint8, pad=18, tile=None):
        """rgb_uint8: (H,W,3). Reflect-pads so image borders match the interior; optional row tiling to save RAM."""
        img = rgb_uint8.astype(np.float32) / 255.0
        H, W_, _ = img.shape
        r = self.scale
        if tile is None or H <= tile:
            p = np.pad(img, ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
            o = self._forward(p)
            return (o[pad * r:(pad + H) * r, pad * r:(pad + W_) * r] * 255 + 0.5).astype(np.uint8)
        # row tiles with overlap (>= receptive field ~ 34px)
        ov = 40
        out = np.zeros((H * r, W_ * r, 3), np.uint8)
        y = 0
        while y < H:
            y1 = min(y + tile, H)
            a, b = max(y - ov, 0), min(y1 + ov, H)
            sub = img[a:b]
            p = np.pad(sub, ((pad if a == 0 else 0, pad if b == H else 0), (pad, pad), (0, 0)), mode='reflect')
            o = self._forward(p)
            top = (pad if a == 0 else 0)
            o = o[top * r:(top + (b - a)) * r, pad * r:(pad + W_) * r]
            out[y * r:y1 * r] = (o[(y - a) * r:(y1 - a) * r] * 255 + 0.5).astype(np.uint8)
            y = y1
        return out
