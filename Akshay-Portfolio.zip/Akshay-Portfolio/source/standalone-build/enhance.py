"""High-quality classical upscaler used for the website images.

No neural-net weights are available offline, so this combines:
  1. mild non-local-means clean-up of JPEG blocking/ringing,
  2. stepwise Lanczos upscaling (never more than 2x per step),
  3. iterative back-projection: nudges the big image until, when shrunk back down, it matches the
     original pixels — this restores crisp edges (text, QR codes) that plain resizing leaves soft,
  4. overshoot clamping (stops halos / ringing around edges),
  5. a light luminance-only unsharp mask.
It cannot invent detail that is not in the source — it makes what IS there cleaner and sharper.
"""
import cv2
import numpy as np


def _upscale(img, scale):
    h, w = img.shape[:2]
    tw, th = round(w * scale), round(h * scale)
    cur = img
    while cur.shape[1] * 1.0001 < tw:
        nw = min(tw, cur.shape[1] * 2)
        nh = min(th, cur.shape[0] * 2)
        cur = cv2.resize(cur, (nw, nh), interpolation=cv2.INTER_LANCZOS4)
    return cur


def enhance(bgr, scale, denoise=2.5, iters=6, sharpen=0.55):
    """bgr: uint8 HxWx3 array. Returns uint8 array scaled by `scale`."""
    h, w = bgr.shape[:2]
    lr = cv2.fastNlMeansDenoisingColored(bgr, None, denoise, denoise, 5, 15) if denoise else bgr
    base = _upscale(lr, scale)
    size = (base.shape[1], base.shape[0])

    # local min/max of the plain upscale = allowed range (kills halos)
    k = cv2.getStructuringElement(cv2.MORPH_RECT, (int(scale) | 1, int(scale) | 1))
    lo = cv2.erode(base, k).astype(np.float32) - 4
    hi = cv2.dilate(base, k).astype(np.float32) + 4

    up = base.astype(np.float32)
    ref = lr.astype(np.float32)
    for _ in range(iters):
        down = cv2.resize(up, (w, h), interpolation=cv2.INTER_AREA)
        err = cv2.resize(ref - down, size, interpolation=cv2.INTER_CUBIC)
        up = np.clip(up + err, lo, hi)

    # light unsharp mask on luminance only (no colour fringes)
    ycc = cv2.cvtColor(np.clip(up, 0, 255).astype(np.uint8), cv2.COLOR_BGR2YCrCb).astype(np.float32)
    y = ycc[..., 0]
    blur = cv2.GaussianBlur(y, (0, 0), sigmaX=max(1.0, scale * 0.45))
    ycc[..., 0] = np.clip(y + sharpen * (y - blur), 0, 255)
    return cv2.cvtColor(ycc.astype(np.uint8), cv2.COLOR_YCrCb2BGR)


def enhance_file(src, dst, scale, max_side=None, quality=90):
    img = cv2.imread(src, cv2.IMREAD_COLOR)
    if max_side:
        scale = min(scale, max_side / max(img.shape[:2]))
    out = enhance(img, scale)
    cv2.imwrite(dst, out, [cv2.IMWRITE_JPEG_QUALITY, quality, cv2.IMWRITE_JPEG_PROGRESSIVE, 1,
                           cv2.IMWRITE_JPEG_SAMPLING_FACTOR, cv2.IMWRITE_JPEG_SAMPLING_FACTOR_444])
    return out.shape[1], out.shape[0]
