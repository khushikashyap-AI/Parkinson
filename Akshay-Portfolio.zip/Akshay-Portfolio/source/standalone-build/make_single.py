"""Turns the built site (index.html + images/) into ONE self-contained index.html.

Every image is re-encoded as WebP and embedded as a base64 data-URI.
  IMG_WEB   grid / hero version   (<=1920 wide, <=2000 tall)
  IMG_FULL  full AI-upscaled size (used by the lightbox / zoom)
  IMG_PAGE  the 16 PDF pages, 3840x2160 (the lightbox "Portfolio page" button)
Usage:  python3 build/make_single.py [web_q] [full_q] [page_q]
"""
import base64, io, json, os, re, sys
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..'))
UP = '/home/claude/upscale/out'
OUT = '/home/claude/single/index.html'
WQ, FQ, PQ = (int(a) for a in (sys.argv[1:4] + ['88', '90', '82'][len(sys.argv[1:4]):]))

html = open(f'{ROOT}/index.html', encoding='utf-8').read()


def webp(im, q):
    b = io.BytesIO()
    im.save(b, 'WEBP', quality=q, method=6)
    return 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()


names = sorted(set(re.findall(r'images/crops/([\w-]+)\.jpg', html)))
pages = sorted(set(re.findall(r'images/pages/(page-\d+)\.jpg', html)))
print(len(names), 'designs,', len(pages), 'pages')

web, full, page = {}, {}, {}
for n in names:
    im = Image.open(f'{UP}/crops/{n}.jpg').convert('RGB')
    # Page version: ~2x the on-screen CSS size (crisp on retina, and only ~2x browser downscale on 1x screens),
    # resized with Lanczos, then lightly sharpened *after* the resize.
    kind = n.split('-')[0]
    cap_w, cap_h = {'social': (1000, 1300), 'poster': (1280, 1400), 'banner': (1840, 900), 'standee': (900, 1400),
                    'brochure': (900, 1300), 'flyer': (900, 1300), 'tee': (1280, 1280), 'extra': (900, 300)}[kind]
    k = min(1.0, cap_w / im.width, cap_h / im.height)
    w = im if k >= 1 else im.resize((round(im.width * k), round(im.height * k)), Image.LANCZOS)
    w = w.filter(ImageFilter.UnsharpMask(radius=1.0, percent=45, threshold=2))
    web[n] = webp(w, WQ)
    # Preview / zoom version: full AI-upscaled size, very light sharpening
    full[n] = webp(im.filter(ImageFilter.UnsharpMask(radius=1.2, percent=40, threshold=2)), FQ)
for p in pages:
    page[p] = webp(Image.open(f'{UP}/pages/{p}.jpg').convert('RGB').filter(ImageFilter.UnsharpMask(radius=1.2, percent=30, threshold=2)), PQ)

# --- 1. <img src="images/crops/NAME.jpg"> -> <img data-img="NAME"> (src is filled in by JS from IMG_WEB) ---
html, n_img = re.subn(r'src="images/crops/([\w-]+)\.jpg"', r'data-img="\1"', html)
assert n_img == len(names) + 0 or n_img >= len(names), n_img

# --- 2. JS changes ---
js_start = html.rindex('<script>') + len('<script>')
js_end = html.rindex('</script>')
js = html[js_start:js_end]


def swap(old, new, count=1):
    global js
    assert js.count(old) >= 1, old[:70]
    js = js.replace(old, new, count)


# fill the images in as the very first thing (the intro pre-loader reads them)
m = re.search(r'  var ITEMS = .*?;\n', js, re.S)
assert m
js = js[:m.end()] + (
    "\n  function imgKey(p) { return String(p).split('/').pop().replace(/\\.jpg$/, ''); }\n"
    "  $$('[data-img]').forEach(function (el) { el.src = IMG_WEB[el.getAttribute('data-img')]; });\n") + js[m.end():]

# lightbox: full-res image (or PDF page) from the embedded dictionaries
swap("      lbImg.onerror = function () { if (lbImg.getAttribute('src') !== it.src) lbImg.src = it.src; };   // missing 4K file -> web version\n", '')
swap("      lbImg.src = lbPage ? it.page : (it.full || it.src);",
     "      lbImg.src = lbPage ? IMG_PAGE[imgKey(it.page)] : IMG_FULL[imgKey(it.full)];")
# browsers block top-level navigation to data: URLs, so "Open image" opens a Blob URL instead
swap("      $('#lbOpen').href = lbImg.src;\n", '')
swap("  $('#lbClose').addEventListener('click', lbClose);",
     "  $('#lbOpen').addEventListener('click', function (e) {\n"
     "    e.preventDefault();\n"
     "    try {\n"
     "      var parts = lbImg.src.split(','), mime = parts[0].match(/:(.*?);/)[1], bin = atob(parts[1]), u8 = new Uint8Array(bin.length);\n"
     "      for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);\n"
     "      window.open(URL.createObjectURL(new Blob([u8], { type: mime })), '_blank');\n"
     "    } catch (err) { /* ignore */ }\n"
     "  });\n"
     "  $('#lbClose').addEventListener('click', lbClose);")

html = html[:js_start] + js + html[js_end:]

# --- 3. image dictionaries, placed just before the main script ---
dicts = ('<script>\nvar IMG_WEB=' + json.dumps(web) + ';\nvar IMG_FULL=' + json.dumps(full) +
         ';\nvar IMG_PAGE=' + json.dumps(page) + ';\n</script>\n  ')
pos = html.rindex('<script>')
html = html[:pos] + dicts + html[pos:]

# --- 4. no remaining external image references ---
assert 'src="images' not in html and 'url(images' not in html and "href=\"images" not in html   # (ITEMS keep the old paths only as dictionary keys)

os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, 'w', encoding='utf-8').write(html)
mb = os.path.getsize(OUT) / 2 ** 20
print(f'{OUT}: {mb:.1f} MiB   (web q{WQ}, full q{FQ}, pages q{PQ})')
