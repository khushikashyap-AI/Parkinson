(function () {
  'use strict';

  /* ------------------------------------------------------------------ helpers */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var ITEMS = /*ITEMS*/;
  var reduced = !!window.__reduced;
  var HAS_GSAP = typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined';
  var ANIM = HAS_GSAP && !reduced;

  if (!ANIM) document.documentElement.classList.remove('js-anim');
  if (HAS_GSAP) gsap.registerPlugin(ScrollTrigger);
  if (HAS_GSAP) gsap.config({ force3D: false });   // keep artwork on whole-pixel 2D transforms (crisper)
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.scrollTo(0, 0);

  /* ------------------------------------------------------------ smooth scroll */
  var lenis = null;
  if (ANIM && typeof Lenis !== 'undefined') {
    lenis = new Lenis({ lerp: 0.1, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
  }
  function lock() {
    if (lenis) lenis.stop();
    document.documentElement.classList.add('is-locked');
  }
  function unlock() {
    if (lenis) lenis.start();
    document.documentElement.classList.remove('is-locked');
  }
  function scrollToId(id) {
    var el = document.getElementById(id);
    if (!el) return;
    if (lenis) lenis.scrollTo(el, { offset: id === 'home' ? 0 : -56, duration: 1.5 });
    else el.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' });
  }

  /* ----------------------------------------------------- nav, menu, progress */
  var nav = $('#nav');
  var menu = $('#menu');
  var burger = $('#burger');

  function setMenu(open) {
    menu.classList.toggle('is-open', open);
    burger.classList.toggle('is-open', open);
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    menu.setAttribute('aria-hidden', String(!open));
  }
  burger.addEventListener('click', function () { setMenu(!menu.classList.contains('is-open')); });

  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-go]');
    if (!a) return;
    e.preventDefault();
    setMenu(false);
    scrollToId(a.getAttribute('data-go'));
  });

  var progress = $('#progress');
  var ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.transform = 'scaleX(' + (h > 0 ? Math.min(window.scrollY / h, 1) : 0) + ')';
      nav.classList.toggle('is-scrolled', window.scrollY > 40);
      ticking = false;
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  function observe(ids, attr, rootMargin, cb) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) cb(en.target.id); });
    }, { rootMargin: rootMargin });
    ids.forEach(function (id) { var el = document.getElementById(id); if (el) io.observe(el); });
  }
  var navIds = $$('.nav__links [data-nav]').map(function (a) { return a.getAttribute('data-nav'); });
  observe(navIds, 'data-nav', '-45% 0px -50% 0px', function (id) {
    $$('[data-nav]').forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('data-nav') === id); });
  });
  var catIds = $$('.catnav [data-cat]').map(function (a) { return 'cat-' + a.getAttribute('data-cat'); });
  observe(catIds, 'data-cat', '-40% 0px -55% 0px', function (id) {
    var key = id.replace('cat-', '');
    $$('.catnav [data-cat]').forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('data-cat') === key); });
  });
  var firstCat = $('.catnav [data-cat]');
  if (firstCat) firstCat.classList.add('is-active');
  var firstNav = $('.nav__links [data-nav="home"]');
  if (firstNav) firstNav.classList.add('is-active');

  /* ------------------------------------------------------- hover tilt (3D) */
  $$('.tilt').forEach(function (el) {
    var max = parseFloat(el.getAttribute('data-max')) || 7;
    el.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      var r = el.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5;
      var y = (e.clientY - r.top) / r.height - 0.5;
      el.style.setProperty('--gx', (x + 0.5) * 100 + '%');
      el.style.setProperty('--gy', (y + 0.5) * 100 + '%');
      el.style.transform = 'perspective(900px) rotateX(' + (-y * 2 * max).toFixed(2) + 'deg) rotateY(' + (x * 2 * max).toFixed(2) + 'deg) scale(1.03)';
    });
    el.addEventListener('pointerleave', function () { el.style.transform = ''; });
  });

  /* ----------------------------------------------------------------- lightbox */
  var lb = $('#lb'), lbFig = $('#lbFig'), lbImg = $('#lbImg');
  var lbIdx = 0, lbPage = false, lbOpen = false, lbZoom = false, lastFocus = null, swapTimer = 0;
  var lbStage = $('#lbStage');
  function setZoom(on) {
    lbZoom = on;
    lbFig.classList.toggle('is-zoomed', on);
    lbStage.classList.toggle('is-zoomed', on);
    $('#lbZoom').textContent = on ? 'Fit' : 'Zoom';
    $('#lbZoom').setAttribute('aria-pressed', String(on));
    if (on) {
      var nw = lbImg.naturalWidth || 800;
      lbImg.style.width = Math.min(Math.max(nw * 0.9, window.innerWidth * 1.2), 3200) + 'px';
      lbStage.scrollTo(0, 0);
    } else lbImg.style.width = '';
  }

  function lbRender(dir, instant) {
    var it = ITEMS[lbIdx];
    function apply() {
      setZoom(false);
      lbImg.onerror = function () { if (lbImg.getAttribute('src') !== it.src) lbImg.src = it.src; };   // missing 4K file -> web version
      lbImg.src = lbPage ? it.page : (it.full || it.src);
      lbImg.alt = it.alt;
      $('#lbOpen').href = lbImg.src;
      $('#lbCount').textContent = String(lbIdx + 1).padStart(2, '0') + ' / ' + String(ITEMS.length).padStart(2, '0');
      $('#lbTitle').textContent = it.title;
      $('#lbMeta').textContent = [it.category, it.tool, it.client].filter(Boolean).join(' · ');
      $('#lbPage').textContent = lbPage ? 'Design only' : 'Portfolio page';
      $('#lbPage').setAttribute('aria-pressed', String(lbPage));
      lbFig.classList.toggle('is-page', lbPage);
      lbFig.classList.remove('swap-out');
      if (!instant) {
        lbFig.classList.add('swap-in');
        setTimeout(function () { lbFig.classList.remove('swap-in'); }, 450);
      }
    }
    clearTimeout(swapTimer);
    lbFig.style.setProperty('--dir', dir || 1);
    if (instant || reduced) { apply(); return; }
    lbFig.classList.add('swap-out');
    swapTimer = setTimeout(apply, 220);
  }
  function lbShow(i) {
    lastFocus = document.activeElement;
    lbIdx = (i + ITEMS.length) % ITEMS.length;
    lbPage = false;
    lbOpen = true;
    lb.hidden = false;
    lbRender(1, true);
    requestAnimationFrame(function () { lb.classList.add('is-open'); $('#lbClose').focus(); });
    lock();
  }
  function lbClose() {
    if (!lbOpen) return;
    lbOpen = false;
    lb.classList.remove('is-open');
    setTimeout(function () { if (!lbOpen) lb.hidden = true; }, 360);
    unlock();
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function lbGo(d) {
    lbIdx = (lbIdx + d + ITEMS.length) % ITEMS.length;
    lbPage = false;
    lbRender(d, false);
  }
  document.addEventListener('click', function (e) {
    var p = e.target.closest('.piece');
    if (p) lbShow(parseInt(p.getAttribute('data-idx'), 10));
  });
  $('#lbClose').addEventListener('click', lbClose);
  $('#lbPrev').addEventListener('click', function () { lbGo(-1); });
  $('#lbNext').addEventListener('click', function () { lbGo(1); });
  $('#lbZoom').addEventListener('click', function () { setZoom(!lbZoom); });
  $('#lbPage').addEventListener('click', function () { lbPage = !lbPage; lbRender(1, true); });
  lb.addEventListener('click', function (e) {
    if (e.target === lb || e.target.id === 'lbStage') lbClose();
  });
  window.addEventListener('keydown', function (e) {
    if (!lbOpen) return;
    if (e.key === 'Escape') lbClose();
    else if (e.key === 'ArrowRight') lbGo(1);
    else if (e.key === 'ArrowLeft') lbGo(-1);
  });
  (function () { // swipe
    var sx = null;
    lbFig.addEventListener('pointerdown', function (e) { sx = e.clientX; });
    window.addEventListener('pointerup', function (e) {
      if (sx === null) return;
      var dx = e.clientX - sx;
      sx = null;
      if (!lbOpen) return;
      if (Math.abs(dx) < 6 && e.target === lbImg) setZoom(!lbZoom);       // tap / click the image to zoom
      else if (!lbZoom && Math.abs(dx) > 90) lbGo(dx < 0 ? 1 : -1);        // swipe to browse
    });
  })();

  /* ------------------------------------------------------------- copy e-mail */
  var copyBtn = $('#copyEmail');
  copyBtn.addEventListener('click', function () {
    var email = $('.contact__row a[href^="mailto:"]').textContent.trim();
    function done() {
      copyBtn.textContent = 'Copied ✓';
      setTimeout(function () { copyBtn.textContent = 'Copy email'; }, 2000);
    }
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(email).then(done, function () { window.prompt('Copy email address:', email); });
    else window.prompt('Copy email address:', email);
  });

  /* ================================================== EXTRAS (plain JS, no GSAP needed) === */
  var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  // ---- custom cursor: yellow dot + ring that grows into a "View" / "Zoom" label (mouse devices only)
  (function cursor() {
    var c = $('#cursor');
    if (!c) return;
    if (!finePointer || reduced) { c.remove(); return; }
    var dot = $('.cursor__dot', c), ring = $('.cursor__ring', c), label = $('b', c);
    var mx = -200, my = -200, rx = -200, ry = -200, shown = false;
    document.documentElement.classList.add('has-cursor');
    window.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      mx = e.clientX; my = e.clientY;
      if (!shown) { shown = true; rx = mx; ry = my; c.classList.remove('is-hidden'); }
    }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { c.classList.add('is-hidden'); shown = false; });
    document.addEventListener('pointerover', function (e) {
      var t = e.target, view = t.closest && t.closest('.piece'), zoom = t.id === 'lbImg';
      var link = t.closest && t.closest('a, button, .catnav a');
      c.classList.toggle('is-view', !!view || zoom);
      c.classList.toggle('is-link', !view && !zoom && !!link);
      label.textContent = zoom ? (lbZoom ? 'Fit' : 'Zoom') : 'View';
    });
    (function tick() {
      rx += (mx - rx) * 0.22; ry += (my - ry) * 0.22;
      dot.style.transform = 'translate(' + Math.round(mx) + 'px,' + Math.round(my) + 'px)';
      ring.style.transform = 'translate(' + Math.round(rx) + 'px,' + Math.round(ry) + 'px)';
      requestAnimationFrame(tick);
    })();
  })();

  // ---- magnetic buttons (uses the independent CSS `translate` property)
  (function magnetic() {
    if (!finePointer || reduced) return;
    $$('.btn, .nav__logo').forEach(function (b) {
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        b.style.translate = Math.round((e.clientX - (r.left + r.width / 2)) * 0.22) + 'px ' + Math.round((e.clientY - (r.top + r.height / 2)) * 0.3) + 'px';
      });
      b.addEventListener('pointerleave', function () { b.style.translate = ''; });
    });
  })();

  // ---- hero: cursor spotlight + depth-parallax of the floating designs (whole pixels only)
  (function heroFx() {
    var hero = $('#home');
    if (!hero || reduced) return;
    var floats = $$('.float', hero), tx = 0, ty = 0, cx = 0, cy = 0, raf = 0;
    function loop() {
      cx += (tx - cx) * 0.08; cy += (ty - cy) * 0.08;
      floats.forEach(function (f) {
        var d = parseFloat(f.getAttribute('data-depth')) || 0.05;
        f.style.translate = Math.round(-cx * d * 700) + 'px ' + Math.round(-cy * d * 500) + 'px';
      });
      raf = (Math.abs(tx - cx) > 0.0005 || Math.abs(ty - cy) > 0.0005) ? requestAnimationFrame(loop) : 0;
    }
    hero.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      var r = hero.getBoundingClientRect();
      tx = e.clientX / window.innerWidth - 0.5; ty = e.clientY / window.innerHeight - 0.5;
      hero.style.setProperty('--mx', Math.round(e.clientX - r.left) + 'px');
      hero.style.setProperty('--my', Math.round(e.clientY - r.top) + 'px');
      if (!raf) raf = requestAnimationFrame(loop);
    });
  })();

  // ---- scroll parallax in WHOLE pixels (fractional offsets re-sample images and make them look soft)
  (function parallax() {
    if (reduced) return;
    var items = [];
    function group(sel, ampFn) {
      $$(sel + ' .par').forEach(function (par, i) { items.push({ el: par, amp: ampFn(i), last: 0 }); });
    }
    group('.grid--posters', function (i) { return [-30, 20, -14][i % 3]; });
    group('.grid--banners', function (i) { return [-30, 20, -14][i % 3] * 0.55; });
    group('.grid--flyers', function (i) { return [-30, 20, -14][i % 3]; });
    group('.grid--standees', function (i) { return i % 2 === 0 ? -46 : 46; });
    var hero = $('#home'), stage = $('.hero__stage', hero), copy = $('.hero__copy', hero);
    var queued = false;
    function update() {
      queued = false;
      var vh = window.innerHeight;
      items.forEach(function (it) {
        var r = it.el.getBoundingClientRect();
        if (r.bottom < -300 || r.top > vh + 300) return;
        var center = r.top - it.last + r.height / 2;                       // un-offset centre
        var p = Math.max(-1, Math.min(1, (center - vh / 2) / ((vh + r.height) / 2)));
        var y = Math.round(-p * it.amp);
        if (y !== it.last) { it.el.style.transform = y ? 'translateY(' + y + 'px)' : ''; it.last = y; }
      });
      var pr = Math.min(Math.max(window.scrollY / Math.max(hero.offsetHeight, 1), 0), 1);
      stage.style.transform = 'translateY(' + Math.round(-0.14 * stage.offsetHeight * pr) + 'px)';
      copy.style.transform = 'translateY(' + Math.round(-0.08 * copy.offsetHeight * pr) + 'px)';
    }
    function queue() { if (!queued) { queued = true; requestAnimationFrame(update); } }
    window.addEventListener('scroll', queue, { passive: true });
    window.addEventListener('resize', queue);
    window.addEventListener('load', queue);
    update();
  })();

  /* ============================================================ ANIMATIONS === */
  var heroTl = null;

  function startSite() {
    nav.classList.add('is-in');
    if (heroTl) heroTl.play();
  }

  if (!ANIM) {
    // No GSAP (offline / blocked) or reduced motion → show everything, no animation.
    var intro0 = $('#intro');
    if (intro0) intro0.remove();
    startSite();
    return;
  }

  /* ------------------------------------------------------------------- intro */
  function particles(canvas) {
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = 0, h = 0, ps = [], raf = 0, alive = true;
    function make(anywhere) {
      return { x: Math.random() * w, y: anywhere ? Math.random() * h : h + 10, r: Math.random() * 1.6 + 0.4,
               v: Math.random() * 0.35 + 0.08, a: Math.random() * 0.6 + 0.2, orange: Math.random() < 0.14, ph: Math.random() * 6.28 };
    }
    function resize() {
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ps = []; for (var i = 0, n = Math.round(w * h / 14000); i < n; i++) ps.push(make(true));
    }
    function loop() {
      if (!alive) return;
      ctx.clearRect(0, 0, w, h);
      ps.forEach(function (p) {
        p.y -= p.v; p.ph += 0.01; p.x += Math.sin(p.ph) * 0.15;
        if (p.y < -10) Object.assign(p, make(false));
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.orange ? 'rgba(255,138,61,' + p.a + ')' : 'rgba(120,170,255,' + p.a + ')';
        ctx.fill();
      });
      raf = requestAnimationFrame(loop);
    }
    resize(); loop();
    window.addEventListener('resize', resize);
    return function stop() { alive = false; cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }

  function runIntro() {
    var intro = $('#intro');
    var q = function (s) { return $$(s, intro); };
    var stopParticles = particles($('canvas', intro));
    lock();

    gsap.set(q('.intro__name .ch'), { yPercent: 115, rotateX: -80, autoAlpha: 0, transformOrigin: '50% 100%' });
    gsap.set(q('.intro__title'), { autoAlpha: 0, letterSpacing: '0.9em' });
    gsap.set(q('.intro__rule'), { autoAlpha: 0, scaleX: 0 });
    gsap.set(q('.intro__tag'), { autoAlpha: 0 });

    var played = false, preloaded = false, exiting = false;
    function exit() {
      if (exiting) return;
      exiting = true;
      gsap.timeline({ defaults: { ease: 'expo.inOut' }, onComplete: function () {
          stopParticles(); intro.remove(); unlock(); ScrollTrigger.refresh();
        } })
        .to(q('.intro__content'), { y: -60, autoAlpha: 0, duration: 0.7, ease: 'power3.in' }, 0)
        .to(q('.intro__streak'), { autoAlpha: 0, duration: 0.4 }, 0)
        .add(startSite, 0.35)
        .to(intro, { clipPath: 'inset(0% 0% 100% 0%)', duration: 1.3 }, 0.3);
    }
    function maybeExit() { if (played && preloaded) exit(); }

    // Preload the hero images while the animation plays (never wait more than 5 s).
    var urls = $$('.hero img').map(function (i) { return i.getAttribute('src'); }).concat([$('.skills img').getAttribute('src')]);
    Promise.all(urls.map(function (u) {
      return new Promise(function (res) { var im = new Image(); im.onload = im.onerror = res; im.src = u; });
    })).then(function () { preloaded = true; maybeExit(); });
    setTimeout(function () { preloaded = true; maybeExit(); }, 5000);

    var counter = $('#introCount');
    var tl = gsap.timeline({
      defaults: { ease: 'expo.out' },
      onUpdate: function () { counter.textContent = String(Math.round(tl.progress() * 100)).padStart(3, '0'); },
      onComplete: function () { played = true; maybeExit(); }
    });
    tl.fromTo(q('.intro__streak'), { xPercent: -160 }, { xPercent: 160, duration: 2.4, stagger: 0.16, ease: 'power2.inOut' }, 0)
      .to(q('.intro__name .ch'), { yPercent: 0, rotateX: 0, autoAlpha: 1, duration: 1.3, stagger: 0.05 }, 0.35)
      .to(q('.intro__rule'), { autoAlpha: 1, scaleX: 1, duration: 1.2, ease: 'expo.inOut' }, 1.3)
      .to(q('.intro__title'), { autoAlpha: 1, letterSpacing: '0.34em', duration: 1.6 }, 1.45)
      .to(q('.intro__tag'), { autoAlpha: 1, duration: 1 }, 1.9)
      .to({}, { duration: 0.5 });

    $('#introSkip').addEventListener('click', exit);
  }

  /* -------------------------------------------------------------------- hero */
  (function hero() {
    var el = $('#home');
    gsap.set($$('.anim', el), { autoAlpha: 0, y: 28 });
    gsap.set($$('.hero__name .ch', el), { yPercent: 115, rotateX: -70, autoAlpha: 0, transformOrigin: '50% 100%' });
    gsap.set($$('.floatIn', el), { autoAlpha: 0, y: 140, scale: 0.85 });
    var floats = $$('.float', el);
    floats.forEach(function (f) { gsap.set(f, { rotate: parseFloat(f.getAttribute('data-rot')) }); });

    heroTl = gsap.timeline({ paused: true, defaults: { ease: 'expo.out' } });
    heroTl.to($$('.hero__name .ch', el), { yPercent: 0, rotateX: 0, autoAlpha: 1, duration: 1.4, stagger: 0.04 }, 0.05)
      .to($$('.anim', el), { autoAlpha: 1, y: 0, duration: 1.1, stagger: 0.09 }, 0.3)
      .to($$('.floatIn', el), { autoAlpha: 1, y: 0, scale: 1, duration: 1.7, stagger: 0.13 }, 0.25);

    // (mouse + scroll parallax of the floating designs is handled by the whole-pixel vanilla code in EXTRAS)
  })();

  /* ------------------------------------------------------------------- about */
  (function about() {
    var el = $('#about');
    var trig = { trigger: el, start: 'top 70%', once: true };
    gsap.fromTo($('.note-wrap', el), { clipPath: 'inset(0% 100% 0% 0%)' },
      { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: 'expo.inOut', clearProps: 'clipPath', scrollTrigger: trig });
    gsap.from($('.note', el), { rotateY: -25, rotate: -6, transformPerspective: 1200, duration: 1.8, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.about__head .line > span', el), { yPercent: 115, duration: 1.2, stagger: 0.1, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.about__body > *', el), { y: 30, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: trig });
    gsap.fromTo($('.skills img', el), { clipPath: 'inset(0% 100% 0% 0%)' },
      { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.4, ease: 'expo.inOut', clearProps: 'clipPath', scrollTrigger: trig });

    var counter = $('.stat__num[data-count]', el);
    if (counter) {
      var o = { v: 0 };
      gsap.to(o, { v: 4.1, duration: 2, ease: 'power2.out', scrollTrigger: trig,
        onUpdate: function () { counter.textContent = o.v.toFixed(2) + '+'; } });
    }
    gsap.from($$('.stat', el), { y: 40, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out',
      scrollTrigger: { trigger: $('.stats', el), start: 'top 88%', once: true } });
  })();

  /* --------------------------------------------------------------- portfolio */
  (function portfolioHead() {
    var el = $('.portfolio__head');
    var trig = { trigger: el, start: 'top 75%', once: true };
    gsap.from($$('.line > span', el), { yPercent: 115, duration: 1.3, stagger: 0.1, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.eyebrow, .portfolio__lede', el), { y: 24, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: trig });
  })();

  function scrub(trigger) { return { trigger: trigger, start: 'top bottom', end: 'bottom top', scrub: true }; }

  var layouts = {
    // Social posts: scale-in + 3D tilt
    social: function (sec) {
      $$('.reveal', sec).forEach(function (el) {
        gsap.from(el, { opacity: 0, scale: 0.8, y: 90, rotateX: 16, transformPerspective: 1000, transformOrigin: '50% 100%',
          duration: 1.2, ease: 'expo.out', clearProps: 'transform,opacity', scrollTrigger: { trigger: el, start: 'top 90%', once: true } });
      });
    },
    // Posters / banners / flyers: masked reveal + zoom settle + parallax
    masked: function (root, dir) {
      $$('.par', root).forEach(function (par, i) {
        var piece = $('.piece', par), img = $('img', par), cap = $('.cap', par);
        var from = dir === 'x' ? 'inset(0% 100% 0% 0%)' : 'inset(100% 0% 0% 0%)';
        gsap.timeline({ scrollTrigger: { trigger: par, start: 'top 88%', once: true } })
          .fromTo(piece, { clipPath: from }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.3, ease: 'expo.inOut', clearProps: 'clipPath' })
          .fromTo(img, { scale: 1.18 }, { scale: 1, duration: 1.9, ease: 'expo.out', clearProps: 'transform' }, 0)
          .from(cap, { opacity: 0, y: 14, duration: 0.8, ease: 'power3.out' }, '-=0.7');
      });
    },
    posters: function (sec) { layouts.masked($('.grid--posters', sec), 'y'); },
    banners: function (sec) { layouts.masked($('.grid--banners', sec), 'x'); },
    // Standees: vertical slides, alternating up / down
    standees: function (sec) {
      $$('.par', sec).forEach(function (par, i) {
        var up = i % 2 === 0;
        gsap.fromTo($('.reveal', par),
          { yPercent: up ? 35 : -35, opacity: 0, clipPath: up ? 'inset(100% 0% 0% 0%)' : 'inset(0% 0% 100% 0%)' },
          { yPercent: 0, opacity: 1, clipPath: 'inset(0% 0% 0% 0%)', duration: 1.5, ease: 'expo.out', clearProps: 'clipPath,transform',
            scrollTrigger: { trigger: par, start: 'top 92%', once: true } });
      });
    },
    // Brochures: scroll-scrubbed page opening + masked flyers
    brochures: function (sec) {
      $$('.spread', sec).forEach(function (sp) {
        var book = $('.spread__book', sp), flap = $('.spread__flap', sp);
        gsap.set(flap, { rotateY: 180 });   // closed: left page folded over the right page
        gsap.set(book, { xPercent: -25 });  // …with the closed book centred
        gsap.timeline({ scrollTrigger: { trigger: sp, start: 'top 82%', end: 'bottom 58%', scrub: 0.7 } })
          .to(book, { xPercent: 0, ease: 'power2.inOut' }, 0)
          .to(flap, { rotateY: 0, ease: 'power2.inOut' }, 0);
      });
      layouts.masked($('.grid--flyers', sec), 'y');
    },
    // T-shirts: product-style circular reveal + gentle float
    tees: function (sec) {
      $$('.par', sec).forEach(function (par, i) {
        var piece = $('.piece', par), img = $('img', par), reveal = $('.reveal', par), cap = $('.cap', par);
        gsap.timeline({ scrollTrigger: { trigger: par, start: 'top 88%', once: true } })
          .fromTo(piece, { clipPath: 'circle(0% at 50% 50%)' }, { clipPath: 'circle(75% at 50% 50%)', duration: 1.5, ease: 'power3.inOut', clearProps: 'clipPath' })
          .fromTo(img, { scale: 1.25, yPercent: 8 }, { scale: 1, yPercent: 0, duration: 1.9, ease: 'expo.out', clearProps: 'transform' }, 0)
          .from(cap, { opacity: 0, y: 14, duration: 0.8 }, '-=0.8');
      });
    }
  };

  $$('.cat').forEach(function (sec) {
    var trig = { trigger: sec, start: 'top 72%', once: true };
    gsap.from($('.cat__no', sec), { xPercent: -45, autoAlpha: 0, duration: 1.5, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.cat__title .line > span', sec), { yPercent: 115, duration: 1.2, stagger: 0.09, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.cat__meta > *', sec), { y: 22, autoAlpha: 0, duration: 0.9, stagger: 0.1, ease: 'expo.out', scrollTrigger: trig });
    gsap.fromTo($('.cat__rule', sec), { scaleX: 0 }, { scaleX: 1, duration: 1.5, ease: 'expo.inOut', scrollTrigger: trig });
    var fn = layouts[sec.getAttribute('data-layout')];
    if (fn) fn(sec);
  });

  /* -------------------------------------------------------------- experience */
  (function experience() {
    var el = $('#experience');
    var head = { trigger: $('.exp__head', el), start: 'top 80%', once: true };
    gsap.from($$('.exp__head .line > span', el), { yPercent: 115, duration: 1.2, stagger: 0.1, ease: 'expo.out', scrollTrigger: head });
    gsap.from($$('.exp__head .eyebrow, .exp__sum', el), { y: 24, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: head });
    gsap.fromTo($('.tl__line-fill', el), { scaleY: 0 },
      { scaleY: 1, ease: 'none', transformOrigin: 'top', scrollTrigger: { trigger: $('.tl', el), start: 'top 70%', end: 'bottom 60%', scrub: true } });
    $$('.tl__item', el).forEach(function (item) {
      gsap.timeline({ scrollTrigger: { trigger: item, start: 'top 80%', once: true } })
        .from($('.tl__dot', item), { scale: 0, duration: 0.7, ease: 'back.out(2.4)' }, 0)
        .from($$('.tl__company .ch', item), { yPercent: 115, duration: 1, stagger: 0.025, ease: 'expo.out' }, 0.1)
        .from($$('.tl__role, .tl__when, .tl__note', item), { x: 40, autoAlpha: 0, duration: 0.9, stagger: 0.12, ease: 'expo.out' }, 0.3);
    });
  })();

  /* ----------------------------------------------------------------- contact */
  (function contact() {
    var el = $('#contact');
    var trig = { trigger: el, start: 'top 65%', once: true };
    gsap.from($$('.contact__title .line > span', el), { yPercent: 115, rotateX: -40, duration: 1.4, stagger: 0.12, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($('.eyebrow', el), { y: 20, autoAlpha: 0, duration: 1, ease: 'expo.out', scrollTrigger: trig });
    gsap.from($$('.contact__row, .contact__actions', el), { y: 40, autoAlpha: 0, duration: 1.1, stagger: 0.14, ease: 'expo.out', delay: 0.4, scrollTrigger: trig });
    gsap.fromTo($('.contact__glow', el), { scale: 0.6, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 2.4, ease: 'expo.out', scrollTrigger: trig });
  })();

  window.addEventListener('load', function () { ScrollTrigger.refresh(); });
  runIntro();
})();
