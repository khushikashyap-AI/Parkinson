"""Builds the standalone site:  index.html  +  images/  (no npm needed).
Run:  python3 build/build.py
Source of truth for crops: /home/claude/portfolio (public/work/crops, public/pages, src/data/manifest.json)
"""
import html, json, os, re, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, '..'))
SRC = '/home/claude/portfolio'
manifest = json.load(open(f'{SRC}/src/data/manifest.json'))

EMAIL = 'Akshay.ingole.1070@gmail.com'
PHONE = '9819539043'
ADDRESS = ['13/A Shantineer, George Nager', 'Opposite Jain Mandir, J.B Nagar', 'Mumbai, Maharashtra-400059']
QUOTE = ('I am open to erudition &amp; climbing the ladder of art that will add to my triumph. '
         'My keen interest in art helps me create visual emotions. '
         'I hold the key to revamping, which gives life the output.')

NAV = [('home', 'Home'), ('about', 'About'), ('portfolio', 'Portfolio'), ('experience', 'Experience'), ('contact', 'Contact')]
JOBS = [
    ('Omotech', 'Associate Marketing Designer', 'January 2026 — Present', 'Current role'),
    ('ImpactGuru', 'Graphic Designer &amp; Content Creator', 'More than 3 years', None),
    ('Wizfx Communication', 'Graphic Designer &amp; Product Photo Editor', '6 months', None),
]

# Only clients whose logo is visible in the design are credited.
CLIENT = {}
for n in range(1, 7): CLIENT[f'social-0{n}'] = 'ImpactGuru'
CLIENT.update({'social-07': 'OMOTEC', 'social-08': 'OMOTEC', 'poster-01': 'ImpactGuru', 'poster-03': 'ImpactGuru',
               'poster-04': 'ImpactGuru', 'banner-04': 'ImpactGuru', 'standee-01': 'ImpactGuru',
               'standee-03': 'OMOTEC', 'standee-04': 'OMOTEC', 'standee-05': 'OMOTEC'})
for n in range(1, 5): CLIENT[f'brochure-0{n}'] = 'OMOTEC'
for n in range(1, 3): CLIENT[f'flyer-0{n}'] = 'OMOTEC'

TITLE = {
    'brochure-01': 'Kumbhathon Nashik 2027 — Page 1', 'brochure-02': 'Kumbhathon Nashik 2027 — Page 2',
    'brochure-03': 'Robotics Education at OMOTEC — Page 1', 'brochure-04': 'Robotics Education at OMOTEC — Page 2',
    'flyer-01': 'Robothon Flyer', 'flyer-02': '4-in-1 Master Classes Flyer',
}
SINGULAR = {'social': 'Social Post', 'poster': 'Poster', 'banner': 'Banner', 'standee': 'Standee', 'tee': 'T-Shirt Design'}
rng = lambda p, n: [f'{p}-{i:02d}' for i in range(1, n + 1)]

CATS = [
    dict(id='social', no='01', title='Social Media Posts', tool='Adobe Photoshop', names=rng('social', 8)),
    dict(id='posters', no='02', title='Posters', tool='Adobe Photoshop', names=rng('poster', 6)),
    dict(id='banners', no='03', title='Banners', tool='Adobe Photoshop', names=rng('banner', 4)),
    dict(id='standees', no='04', title='Standees', tool='Adobe Illustrator', names=rng('standee', 5)),
    dict(id='brochures', no='05', title='Brochures & Flyers', tool='Adobe Illustrator', names=rng('brochure', 4) + rng('flyer', 2)),
    dict(id='tshirts', no='06', title='T-Shirt Designs', tool=None, names=rng('tee', 5)),
]
LAYOUT = {'social': 'social', 'posters': 'posters', 'banners': 'banners', 'standees': 'standees', 'brochures': 'brochures', 'tshirts': 'tees'}

E = html.escape
items, idx = [], 0
for c in CATS:
    c['items'] = []
    for n in c['names']:
        kind, num = n.split('-')
        m = manifest[n]
        title = TITLE.get(n, f'{SINGULAR.get(kind, kind)} {num}')
        it = dict(id=n, idx=idx, kind=kind, title=title, client=CLIENT.get(n), category=c['title'],
                  tool=None if kind == 'flyer' else c['tool'], src=f'images/crops/{n}.jpg',
                  page=f"images/pages/page-{m['page']:02d}.jpg", w=m['w'], h=m['h'])
        it['alt'] = title + (f" — {it['client']}" if it['client'] else '')
        it['full'] = f'images/4k/{n}.jpg'   # full-resolution (AI-upscaled) version for the preview / zoom
        c['items'].append(it); items.append(it); idx += 1


def chars(text):
    return ''.join(f'<span class="ch" aria-hidden="true">{"&nbsp;" if ch == " " else E(ch)}</span>' for ch in text)


def piece(it, mx=7):
    return (f'<div class="tilt" data-max="{mx}"><button type="button" class="piece" data-idx="{it["idx"]}" aria-label="Open {E(it["title"])}">'
            f'<img src="{it["src"]}" width="{it["w"]}" height="{it["h"]}" alt="{E(it["alt"])}" loading="lazy" decoding="async" draggable="false">'
            f'<span class="piece__veil" aria-hidden="true"><span class="piece__cta">View</span></span></button>'
            f'<span class="tilt__glow" aria-hidden="true"></span></div>')


def figure(it, mx=7):
    cap = f'<span>{E(it["title"])}</span>' + (f'<em>{it["client"]}</em>' if it['client'] else '')
    return f'<div class="par"><figure class="reveal">{piece(it, mx)}<figcaption class="cap">{cap}</figcaption></figure></div>'


def spread(a, b, label):
    return (f'<div class="spread"><div class="spread__book"><div class="spread__flap">'
            f'<div class="spread__face spread__front">{piece(a, 3)}</div>'
            f'<div class="spread__face spread__back" aria-hidden="true"><span>{E(label)}</span></div></div>'
            f'<div class="spread__page">{piece(b, 3)}</div></div>'
            f'<p class="cap cap--center"><span>{E(label)}</span><em>{a["client"]}</em></p></div>')


def category(c):
    words = ''.join(f'<span class="line"><span>{E(w)}</span></span>' for w in c['title'].split(' '))
    meta = (f'<span class="tag">{c["tool"]}</span>' if c['tool'] else '') + f'<span class="count">{len(c["items"])} pieces</span>'
    lay = LAYOUT[c['id']]
    its = c['items']
    mx = {'social': 9, 'posters': 3, 'banners': 2, 'standees': 6, 'tees': 6}.get(lay, 5)
    if lay == 'brochures':
        b = [i for i in its if i['kind'] == 'brochure']; f = [i for i in its if i['kind'] == 'flyer']
        body = ('<h3 class="subhead">Brochures</h3><div class="spreads">'
                + spread(b[0], b[1], 'Kumbhathon Nashik 2027') + spread(b[2], b[3], 'Robotics Education at OMOTEC')
                + '</div><h3 class="subhead">Flyers</h3><div class="grid grid--flyers">' + ''.join(figure(i, 5) for i in f) + '</div>')
    else:
        body = f'<div class="grid grid--{lay}">' + ''.join(figure(i, mx) for i in its) + '</div>'
    return (f'<section id="cat-{c["id"]}" class="cat cat--{c["id"]}" data-layout="{lay}" aria-labelledby="h-{c["id"]}">'
            f'<header class="cat__head"><span class="cat__no" aria-hidden="true">{c["no"]}</span>'
            f'<h3 class="cat__title" id="h-{c["id"]}">{words}</h3><div class="cat__meta">{meta}</div></header>'
            f'<span class="cat__rule" aria-hidden="true"></span>{body}</section>')


# hero floating cards
HERO = [('social-02', -7, 0.05), ('social-07', 5, 0.08), ('social-08', -3, 0.035), ('tee-01', 8, 0.065)]
hero_html = ''.join(
    f'<div class="float f{i + 1}" data-rot="{r}" data-depth="{d}"><div class="floatIn"><img src="images/crops/{n}.jpg" '
    f'width="{manifest[n]["w"]}" height="{manifest[n]["h"]}" alt="" loading="eager" decoding="async" draggable="false"></div></div>'
    for i, (n, r, d) in enumerate(HERO))

jobs_html = ''.join(
    f'<li class="tl__item"><span class="tl__dot" aria-hidden="true"></span><span class="tl__no" aria-hidden="true">0{i + 1}</span>'
    f'<div class="tl__body"><h3 class="tl__company" aria-label="{E(co)}"><span class="mask-line">{chars(co)}</span></h3>'
    f'<p class="tl__role">{role}</p><p class="tl__when">{when}</p>'
    + (f'<span class="tl__note">{note}</span>' if note else '') + '</div></li>'
    for i, (co, role, when, note) in enumerate(JOBS))

nav_links = '\n'.join(f'      <a href="#{i}" data-go="{i}" data-nav="{i}">{l}</a>' for i, l in NAV)
menu_links = '\n'.join(f'      <a href="#{i}" data-go="{i}" data-nav="{i}"><small>0{n + 1}</small>{l}</a>' for n, (i, l) in enumerate(NAV))
catnav = '\n'.join(f'        <a href="#cat-{c["id"]}" data-go="cat-{c["id"]}" data-cat="{c["id"]}"><span>{E(c["title"])}</span></a>' for c in CATS)

lb_items = [{k: it[k] for k in ('title', 'category', 'tool', 'client', 'src', 'full', 'page', 'alt')} for it in items]

# ---- black & yellow theme (yellow sampled from the PDF cover: rgb(250,205,26)) ----
THEME = [
    ('#08162a', '#050505'), ('#0b1d38', '#0c0c0b'), ('#0f2747', '#151513'), ('#0d2342', '#17150f'),
    ('#123564', '#2b2509'), ('#0c2447', '#14120a'), ('#2f7bff', '#FACD1A'), ('#5aa0ff', '#FFDD55'),
    ('#ff8a3d', '#FFB000'), ('#4b8fff', '#FFE066'), ('#f4f7fb', '#f6f5ef'), ('#a7b4c8', '#aaa89c'), ('#6f7f98', '#706e63'),
    ('rgba(47, 123, 255,', 'rgba(250, 205, 26,'), ('rgba(90, 160, 255,', 'rgba(255, 221, 85,'),
    ('rgba(255, 138, 61,', 'rgba(255, 176, 0,'), ('rgba(8, 22, 42,', 'rgba(5, 5, 5,'),
    ('rgba(5, 12, 24,', 'rgba(0, 0, 0,'), ('rgba(11, 29, 56,', 'rgba(10, 10, 9,'),
    ('%2308162A', '%23050505'), ('%232f7bff', '%23FACD1A'),
]
def theme(t):
    for a, b in THEME:
        t = re.sub(re.escape(a), b, t, flags=re.I)
    return t

css = theme(open(f'{SRC}/src/styles.css').read() + '\n' + open(f'{HERE}/overrides.css').read())
js = open(f'{HERE}/app.js').read().replace('/*ITEMS*/', json.dumps(lb_items, ensure_ascii=False))
js = js.replace("'rgba(255,138,61,'", "'rgba(255,255,255,'").replace("'rgba(120,170,255,'", "'rgba(250,205,26,'")
page = theme(open(f'{HERE}/template.html').read())

rep = {
    '/*CSS*/': css, '/*JS*/': js,
    '<!--NAVLINKS-->': nav_links, '<!--MENULINKS-->': menu_links, '<!--HEROFLOATS-->': hero_html,
    '<!--CATNAV-->': catnav, '<!--CATEGORIES-->': '\n'.join(category(c) for c in CATS), '<!--JOBS-->': jobs_html,
    '__EMAIL__': EMAIL, '__PHONE__': PHONE, '__ADDRESS__': ''.join(f'<span>{a}</span>' for a in ADDRESS), '__QUOTE__': QUOTE,
    '__HERO_AKSHAY__': chars('Akshay'), '__HERO_INGOLE__': chars('Ingole'),
    '__INTRO_AKSHAY__': chars('AKSHAY'), '__INTRO_INGOLE__': chars('INGOLE'),
    '__SK_W__': str(manifest['extra-skills']['w']), '__SK_H__': str(manifest['extra-skills']['h']),
}
for k, v in rep.items():
    page = page.replace(k, v)
left = re.findall(r'__[A-Z_]+__|<!--[A-Z]+-->', page)
assert not left, left

# ---- images ----------------------------------------------------------------------------------
# Primary: Real-ESRGAN x4 (AI super-resolution) outputs from /home/claude/upscale/run_batch.py
#   crops -> images/4k/<name>.jpg   (full 4x, up to ~3400 px)  + images/crops/<name>.jpg (<=1920 px web version for the grid)
#   pages -> images/pages/page-XX.jpg (true 4K, 3840x2160)
# Fallback for any image the AI pass did not produce: classical enhancer in build/enhance.py.
import sys
from PIL import Image
sys.path.insert(0, HERE)
from enhance import enhance_file
UP = '/home/claude/upscale/out'
for d in ('crops', '4k', 'pages', 'hd'):
    shutil.rmtree(f'{OUT}/images/{d}', ignore_errors=True)
for d in ('crops', '4k', 'pages'):
    os.makedirs(f'{OUT}/images/{d}')
ai, fallback = 0, []
for n in manifest:
    full_dst = f'{OUT}/images/4k/{n}.jpg'
    if os.path.exists(f'{UP}/crops/{n}.jpg'):
        shutil.copy(f'{UP}/crops/{n}.jpg', full_dst); ai += 1
    else:
        enhance_file(f'{SRC}/public/work/crops/{n}.jpg', full_dst, 4, max_side=3840, quality=90); fallback.append(n)
    full = Image.open(full_dst).convert('RGB')
    k = min(1.0, 1920 / full.width, 2400 / full.height)   # grid version: <=1920 wide, <=2400 tall
    web = full if k >= 1 else full.resize((round(full.width * k), round(full.height * k)), Image.LANCZOS)
    web.save(f'{OUT}/images/crops/{n}.jpg', quality=90, subsampling=0, optimize=True)
for p in range(1, 17):
    dst = f'{OUT}/images/pages/page-{p:02d}.jpg'
    if os.path.exists(f'{UP}/pages/page-{p:02d}.jpg'):
        shutil.copy(f'{UP}/pages/page-{p:02d}.jpg', dst); ai += 1
    else:
        enhance_file(f'{SRC}/public/pages/page-{p:02d}.jpg', dst, 2, max_side=3840, quality=86); fallback.append(f'page-{p:02d}')
print('images: AI-upscaled', ai, '| classical fallback', len(fallback), fallback)
open(f'{OUT}/index.html', 'w', encoding='utf-8').write(page)
print('index.html', round(len(page) / 1024), 'KB;', len(items), 'items')
