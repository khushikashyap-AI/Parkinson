import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' keeps the built site portable (works from any sub-folder or static host).
export default defineConfig({
  base: './',
  plugins: [react()],
});
