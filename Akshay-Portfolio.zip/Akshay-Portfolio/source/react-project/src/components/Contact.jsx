import { useLayoutEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { PROFILE } from '../data/data.js';
import { prefersReducedMotion } from '../lib/scroll.js';

gsap.registerPlugin(ScrollTrigger);

export default function Contact() {
  const root = useRef(null);
  const [copied, setCopied] = useState(false);

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(root);
      const trigger = { trigger: root.current, start: 'top 65%', once: true };
      gsap.from(q('.contact__title .line > span'), { yPercent: 115, rotateX: -40, duration: 1.4, stagger: 0.12, ease: 'expo.out', scrollTrigger: trigger });
      gsap.from(q('.eyebrow'), { y: 20, autoAlpha: 0, duration: 1, ease: 'expo.out', scrollTrigger: trigger });
      gsap.from(q('.contact__row, .contact__actions'), { y: 40, autoAlpha: 0, duration: 1.1, stagger: 0.14, ease: 'expo.out', delay: 0.4, scrollTrigger: trigger });
      gsap.fromTo(q('.contact__glow'), { scale: 0.6, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 2.4, ease: 'expo.out', scrollTrigger: trigger });
    }, root);
    return () => ctx.revert();
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(PROFILE.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt('Copy email address:', PROFILE.email);
    }
  };

  return (
    <section id="contact" className="section contact" ref={root}>
      <div className="contact__glow" aria-hidden="true" />
      <p className="eyebrow">Contact</p>
      <h2 className="contact__title">
        <span className="line"><span>Let’s work</span></span>
        <span className="line"><span className="accent">together</span></span>
      </h2>

      <div className="contact__rows">
        <div className="contact__row">
          <span className="contact__k">Email</span>
          <a href={`mailto:${PROFILE.email}?subject=Portfolio%20enquiry`}>{PROFILE.email}</a>
        </div>
        <div className="contact__row">
          <span className="contact__k">Phone</span>
          <a href={`tel:${PROFILE.phone}`}>{PROFILE.phone}</a>
        </div>
        <div className="contact__row">
          <span className="contact__k">Address</span>
          <address>
            {PROFILE.address.map((l) => (
              <span key={l}>{l}</span>
            ))}
          </address>
        </div>
      </div>

      <div className="contact__actions">
        <a className="btn btn--primary btn--lg" href={`mailto:${PROFILE.email}?subject=Portfolio%20enquiry`}>
          Email me <span aria-hidden="true">→</span>
        </a>
        <button type="button" className="btn btn--ghost btn--lg" onClick={copy} aria-live="polite">
          {copied ? 'Copied ✓' : 'Copy email'}
        </button>
      </div>
    </section>
  );
}
