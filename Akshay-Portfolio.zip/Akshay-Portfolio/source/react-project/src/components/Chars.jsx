// Splits text into per-character spans so GSAP can stagger them (kinetic typography).
export default function Chars({ text, className = '' }) {
  return (
    <span className={className} aria-label={text}>
      {text.split('').map((c, i) => (
        <span key={i} className="ch" aria-hidden="true">
          {c === ' ' ? ' ' : c}
        </span>
      ))}
    </span>
  );
}
