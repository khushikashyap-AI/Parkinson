import { useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { PROFILE, STATS } from '../data/data.js';
import { prefersReducedMotion } from '../lib/scroll.js';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const root = useRef(null);

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(root);
      const trigger = { trigger: root.current, start: 'top 70%', once: true };

      // The note keeps its own torn-edge clip-path, so the wipe runs on its wrapper instead.
      gsap.fromTo(
        q('.note-wrap'),
        { clipPath: 'inset(0% 100% 0% 0%)' },
        { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: 'expo.inOut', clearProps: 'clipPath', scrollTrigger: trigger },
      );
      gsap.from(q('.note'), {
        rotateY: -25,
        rotate: -6,
        transformPerspective: 1200,
        duration: 1.8,
        ease: 'expo.out',
        scrollTrigger: trigger,
      });
      gsap.from(q('.about__head .line > span'), { yPercent: 115, duration: 1.2, stagger: 0.1, ease: 'expo.out', scrollTrigger: trigger });
      gsap.from(q('.about__body > *'), { y: 30, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: trigger });
      gsap.fromTo(
        q('.skills img'),
        { clipPath: 'inset(0% 100% 0% 0%)' },
        { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.4, ease: 'expo.inOut', clearProps: 'clipPath', scrollTrigger: trigger },
      );

      // Count the headline stat up to 4.10
      const counter = q('.stat__num[data-count]')[0];
      if (counter) {
        const o = { v: 0 };
        gsap.to(o, {
          v: 4.1,
          duration: 2,
          ease: 'power2.out',
          scrollTrigger: trigger,
          onUpdate: () => {
            counter.textContent = `${o.v.toFixed(2)}+`;
          },
        });
      }
      gsap.from(q('.stat'), { y: 40, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: { trigger: q('.stats')[0], start: 'top 88%', once: true } });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="about" className="section about" ref={root}>
      <div className="about__grid">
        <div className="note-wrap">
          <figure className="note">
            <span className="note__tape note__tape--a" aria-hidden="true" />
            <span className="note__tape note__tape--b" aria-hidden="true" />
            <blockquote>
              <span className="note__mark" aria-hidden="true">“</span>
              {PROFILE.quote}
            </blockquote>
          </figure>
        </div>

        <div className="about__text">
          <div className="about__head">
            <p className="eyebrow">About</p>
            <h2 className="h2">
              <span className="line">
                <span>Visual emotions,</span>
              </span>
              <span className="line">
                <span>carefully revamped.</span>
              </span>
            </h2>
          </div>
          <div className="about__body">
            <p>
              Graphic and marketing designer with {PROFILE.experienceYears} years of experience — currently an Associate Marketing
              Designer at Omotech, previously at ImpactGuru and Wizfx Communication.
            </p>
            <div className="skills">
              <p className="eyebrow">Skills</p>
              <img src={PROFILE.skillsImage} alt={PROFILE.skillsAlt} width={712} height={108} loading="lazy" decoding="async" />
            </div>
          </div>
        </div>
      </div>

      <div className="stats">
        {STATS.map((s, i) => (
          <div className="stat" key={s.label}>
            <span className="stat__num" {...(i === 0 ? { 'data-count': true } : {})}>
              {s.value}
            </span>
            <span className="stat__label">{s.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
