import { useEffect, useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Chars from './Chars.jsx';
import { HERO_FLOATS, PROFILE } from '../data/data.js';
import { prefersReducedMotion, scrollToId } from '../lib/scroll.js';

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ ready }) {
  const root = useRef(null);
  const tlRef = useRef(null);

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const el = root.current;
    const movers = [];

    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(el);

      // Hidden start state (revealed once the intro wipes away).
      gsap.set(q('.anim'), { autoAlpha: 0, y: 28 });
      gsap.set(q('.hero__name .ch'), { yPercent: 115, rotateX: -70, autoAlpha: 0, transformOrigin: '50% 100%' });
      gsap.set(q('.floatIn'), { autoAlpha: 0, y: 140, scale: 0.85 });
      q('.float').forEach((f, i) => gsap.set(f, { rotate: HERO_FLOATS[i].rot }));

      const tl = gsap.timeline({ paused: true, defaults: { ease: 'expo.out' } });
      tl.to(q('.hero__name .ch'), { yPercent: 0, rotateX: 0, autoAlpha: 1, duration: 1.4, stagger: 0.04 }, 0.05)
        .to(q('.anim'), { autoAlpha: 1, y: 0, duration: 1.1, stagger: 0.09 }, 0.3)
        .to(q('.floatIn'), { autoAlpha: 1, y: 0, scale: 1, duration: 1.7, stagger: 0.13 }, 0.25);
      tlRef.current = tl;

      // Idle float on each card.
      q('.float img').forEach((img, i) => {
        gsap.to(img, { y: 14, duration: 3 + i * 0.45, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: i * 0.25 });
      });

      // Mouse parallax (each card moves at its own depth).
      q('.float').forEach((f, i) => {
        movers.push({
          x: gsap.quickTo(f, 'x', { duration: 1.2, ease: 'power3' }),
          y: gsap.quickTo(f, 'y', { duration: 1.2, ease: 'power3' }),
          d: HERO_FLOATS[i].depth,
        });
      });

      // Scroll parallax for the whole stage.
      gsap.to(q('.hero__stage'), {
        yPercent: -14,
        ease: 'none',
        scrollTrigger: { trigger: el, start: 'top top', end: 'bottom top', scrub: true },
      });
      gsap.to(q('.hero__copy'), {
        yPercent: -8,
        ease: 'none',
        scrollTrigger: { trigger: el, start: 'top top', end: 'bottom top', scrub: true },
      });
    }, root);

    const onMove = (e) => {
      const nx = e.clientX / window.innerWidth - 0.5;
      const ny = e.clientY / window.innerHeight - 0.5;
      movers.forEach((m) => {
        m.x(-nx * m.d * 700);
        m.y(-ny * m.d * 500);
      });
    };
    el.addEventListener('pointermove', onMove);

    return () => {
      el.removeEventListener('pointermove', onMove);
      ctx.revert();
    };
  }, []);

  useEffect(() => {
    if (ready) tlRef.current?.play();
  }, [ready]);

  return (
    <section id="home" className="hero" ref={root}>
      <div className="hero__glow" aria-hidden="true" />

      <div className="hero__copy">
        <p className="eyebrow anim">{PROFILE.edition}</p>
        <h2 className="hero__name" aria-label={PROFILE.name}>
          <span className="mask-line">
            <Chars text="Akshay" />
          </span>
          <span className="mask-line">
            <Chars text="Ingole" />
          </span>
        </h2>
        <p className="hero__title anim">{PROFILE.title}</p>
        <p className="hero__lede anim">
          {PROFILE.experienceYears} years of experience in graphic and marketing design — social media, print and
          product visuals.
        </p>
        <div className="hero__cta anim">
          <a
            className="btn btn--primary"
            href="#portfolio"
            onClick={(e) => {
              e.preventDefault();
              scrollToId('portfolio');
            }}
          >
            View portfolio <span aria-hidden="true">↓</span>
          </a>
          <a className="btn btn--ghost" href={`mailto:${PROFILE.email}?subject=Portfolio%20enquiry`}>
            Email me
          </a>
        </div>
      </div>

      <div className="hero__stage" aria-hidden="true">
        {HERO_FLOATS.map((f, i) => (
          <div key={f.id} className={`float f${i + 1}`}>
            <div className="floatIn">
              <img src={f.src} width={f.w} height={f.h} alt="" loading="eager" decoding="async" draggable="false" />
            </div>
          </div>
        ))}
      </div>

      <div className="hero__scroll anim" aria-hidden="true">
        <span>Scroll</span>
        <i />
      </div>
    </section>
  );
}
