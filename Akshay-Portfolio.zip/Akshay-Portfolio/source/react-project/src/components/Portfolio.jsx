import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
import Figure, { Piece } from './Figure.jsx';
import { CATEGORIES } from '../data/data.js';
import { prefersReducedMotion, scrollToId } from '../lib/scroll.js';

gsap.registerPlugin(ScrollTrigger);

// Runs `setup` inside a gsap.context scoped to `ref`, skipped when the visitor prefers reduced motion.
function useAnimation(ref, setup) {
  useLayoutEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const ctx = gsap.context(() => setup(ref.current), ref);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

const scrub = (trigger) => ({ trigger, start: 'top bottom', end: 'bottom top', scrub: true });

/* ---------- 01 · Social posts: scale-in + 3D tilt ---------- */
function SocialLayout({ cat, onOpen }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    gsap.utils.toArray('.reveal', root).forEach((el) => {
      gsap.from(el, {
        opacity: 0,
        scale: 0.8,
        y: 90,
        rotateX: 16,
        transformPerspective: 1000,
        transformOrigin: '50% 100%',
        duration: 1.2,
        ease: 'expo.out',
        scrollTrigger: { trigger: el, start: 'top 90%', once: true },
      });
    });
  });
  return (
    <div className="grid grid--social" ref={ref}>
      {cat.items.map((it) => (
        <Figure key={it.id} item={it} onOpen={onOpen} max={9} />
      ))}
    </div>
  );
}

/* ---------- 02 / 03 · Posters & banners: masked zoom reveal + parallax ---------- */
function MaskedLayout({ items, onOpen, dir = 'y', className = '' }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    gsap.utils.toArray('.par', root).forEach((par, i) => {
      const piece = par.querySelector('.piece');
      const img = par.querySelector('img');
      const cap = par.querySelector('.cap');
      const from = dir === 'x' ? 'inset(0% 100% 0% 0%)' : 'inset(100% 0% 0% 0%)';

      gsap
        .timeline({ scrollTrigger: { trigger: par, start: 'top 88%', once: true } })
        .fromTo(piece, { clipPath: from }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.3, ease: 'expo.inOut', clearProps: 'clipPath' })
        .fromTo(img, { scale: 1.35 }, { scale: 1, duration: 1.9, ease: 'expo.out' }, 0)
        .from(cap, { opacity: 0, y: 14, duration: 0.8, ease: 'power3.out' }, '-=0.7');

      const s = [-30, 20, -14][i % 3] * (dir === 'x' ? 0.55 : 1);
      gsap.fromTo(par, { y: -s }, { y: s, ease: 'none', scrollTrigger: scrub(par) });
    });
  });
  return (
    <div className={`grid ${className}`} ref={ref}>
      {items.map((it) => (
        <Figure key={it.id} item={it} onOpen={onOpen} max={5} />
      ))}
    </div>
  );
}

/* ---------- 04 · Standees: vertical slides ---------- */
function StandeeLayout({ cat, onOpen }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    gsap.utils.toArray('.par', root).forEach((par, i) => {
      const up = i % 2 === 0;
      const reveal = par.querySelector('.reveal');
      gsap.fromTo(
        reveal,
        { yPercent: up ? 35 : -35, opacity: 0, clipPath: up ? 'inset(100% 0% 0% 0%)' : 'inset(0% 0% 100% 0%)' },
        {
          yPercent: 0,
          opacity: 1,
          clipPath: 'inset(0% 0% 0% 0%)',
          duration: 1.5,
          ease: 'expo.out',
          clearProps: 'clipPath',
          scrollTrigger: { trigger: par, start: 'top 92%', once: true },
        },
      );
      gsap.fromTo(par, { y: up ? 46 : -46 }, { y: up ? -46 : 46, ease: 'none', scrollTrigger: scrub(par) });
    });
  });
  return (
    <div className="grid grid--standees" ref={ref}>
      {cat.items.map((it) => (
        <Figure key={it.id} item={it} onOpen={onOpen} max={6} />
      ))}
    </div>
  );
}

/* ---------- 05 · Brochures: page-opening spread ---------- */
function Spread({ left, right, label, onOpen }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    const book = root.querySelector('.spread__book');
    const flap = root.querySelector('.spread__flap');
    // Closed: the left page lies folded over the right page, book centred.
    gsap.set(flap, { rotateY: 180 });
    gsap.set(book, { xPercent: -25 });
    gsap
      .timeline({ scrollTrigger: { trigger: root, start: 'top 82%', end: 'bottom 58%', scrub: 0.7 } })
      .to(book, { xPercent: 0, ease: 'power2.inOut' }, 0)
      .to(flap, { rotateY: 0, ease: 'power2.inOut' }, 0);
  });
  return (
    <div className="spread" ref={ref}>
      <div className="spread__book">
        <div className="spread__flap">
          <div className="spread__face spread__front">
            <Piece item={left} onOpen={onOpen} max={3} />
          </div>
          <div className="spread__face spread__back" aria-hidden="true">
            <span>{label}</span>
          </div>
        </div>
        <div className="spread__page">
          <Piece item={right} onOpen={onOpen} max={3} />
        </div>
      </div>
      <p className="cap cap--center">
        <span>{label}</span>
        <em>{left.client}</em>
      </p>
    </div>
  );
}

function BrochureLayout({ cat, onOpen }) {
  const b = cat.items.filter((i) => i.kind === 'brochure');
  const f = cat.items.filter((i) => i.kind === 'flyer');
  return (
    <>
      <h3 className="subhead">Brochures</h3>
      <div className="spreads">
        <Spread left={b[0]} right={b[1]} label="Kumbhathon Nashik 2027" onOpen={onOpen} />
        <Spread left={b[2]} right={b[3]} label="Robotics Education at OMOTEC" onOpen={onOpen} />
      </div>
      <h3 className="subhead">Flyers</h3>
      <MaskedLayout items={f} onOpen={onOpen} dir="y" className="grid--flyers" />
    </>
  );
}

/* ---------- 06 · T-shirts: product-style reveal ---------- */
function TeeLayout({ cat, onOpen }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    gsap.utils.toArray('.par', root).forEach((par, i) => {
      const piece = par.querySelector('.piece');
      const img = par.querySelector('img');
      const reveal = par.querySelector('.reveal');
      const cap = par.querySelector('.cap');
      gsap
        .timeline({ scrollTrigger: { trigger: par, start: 'top 88%', once: true } })
        .fromTo(piece, { clipPath: 'circle(0% at 50% 50%)' }, { clipPath: 'circle(75% at 50% 50%)', duration: 1.5, ease: 'power3.inOut', clearProps: 'clipPath' })
        .fromTo(img, { scale: 1.25, yPercent: 8 }, { scale: 1, yPercent: 0, duration: 1.9, ease: 'expo.out' }, 0)
        .from(cap, { opacity: 0, y: 14, duration: 0.8 }, '-=0.8');
      // Gentle product "float" once revealed.
      gsap.to(reveal, { y: -9, duration: 3.2 + i * 0.35, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: 2 });
    });
  });
  return (
    <div className="grid grid--tees" ref={ref}>
      {cat.items.map((it) => (
        <Figure key={it.id} item={it} onOpen={onOpen} max={6} />
      ))}
    </div>
  );
}

/* ---------- category section + header ---------- */
function CategorySection({ cat, onOpen }) {
  const ref = useRef(null);
  useAnimation(ref, (root) => {
    const q = gsap.utils.selector(root);
    const trigger = { trigger: root, start: 'top 72%', once: true };
    gsap.from(q('.cat__no'), { xPercent: -45, autoAlpha: 0, duration: 1.5, ease: 'expo.out', scrollTrigger: trigger });
    gsap.from(q('.cat__title .line > span'), { yPercent: 115, duration: 1.2, stagger: 0.09, ease: 'expo.out', scrollTrigger: trigger });
    gsap.from(q('.cat__meta > *'), { y: 22, autoAlpha: 0, duration: 0.9, stagger: 0.1, ease: 'expo.out', scrollTrigger: trigger });
    gsap.fromTo(q('.cat__rule'), { scaleX: 0 }, { scaleX: 1, duration: 1.5, ease: 'expo.inOut', scrollTrigger: trigger });
  });

  const layouts = {
    social: <SocialLayout cat={cat} onOpen={onOpen} />,
    posters: <MaskedLayout items={cat.items} onOpen={onOpen} dir="y" className="grid--posters" />,
    banners: <MaskedLayout items={cat.items} onOpen={onOpen} dir="x" className="grid--banners" />,
    standees: <StandeeLayout cat={cat} onOpen={onOpen} />,
    brochures: <BrochureLayout cat={cat} onOpen={onOpen} />,
    tees: <TeeLayout cat={cat} onOpen={onOpen} />,
  };

  return (
    <section id={`cat-${cat.id}`} className={`cat cat--${cat.id}`} ref={ref} aria-labelledby={`h-${cat.id}`}>
      <header className="cat__head">
        <span className="cat__no" aria-hidden="true">{cat.no}</span>
        <h3 className="cat__title" id={`h-${cat.id}`}>
          {cat.title.split(' ').map((w, i) => (
            <span className="line" key={i}>
              <span>{w}</span>
            </span>
          ))}
        </h3>
        <div className="cat__meta">
          {cat.tool && <span className="tag">{cat.tool}</span>}
          <span className="count">{cat.items.length} pieces</span>
        </div>
      </header>
      <span className="cat__rule" aria-hidden="true" />
      {layouts[cat.layout]}
    </section>
  );
}

/* ---------- sticky category switcher ---------- */
function CategoryNav() {
  const [active, setActive] = useState(CATEGORIES[0].id);
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id.replace('cat-', ''))),
      { rootMargin: '-40% 0px -55% 0px' },
    );
    CATEGORIES.forEach((c) => {
      const el = document.getElementById(`cat-${c.id}`);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  return (
    <nav className="catnav" aria-label="Portfolio categories">
      <div className="catnav__inner">
        {CATEGORIES.map((c) => (
          <a
            key={c.id}
            href={`#cat-${c.id}`}
            className={active === c.id ? 'is-active' : ''}
            onClick={(e) => {
              e.preventDefault();
              scrollToId(`cat-${c.id}`);
            }}
          >
            {active === c.id && <motion.span layoutId="catnav-pill" className="catnav__pill" transition={{ type: 'spring', stiffness: 380, damping: 32 }} />}
            <span>{c.title}</span>
          </a>
        ))}
      </div>
    </nav>
  );
}

export default function Portfolio({ onOpen }) {
  const head = useRef(null);
  useAnimation(head, (root) => {
    const q = gsap.utils.selector(root);
    const trigger = { trigger: root, start: 'top 75%', once: true };
    gsap.from(q('.line > span'), { yPercent: 115, duration: 1.3, stagger: 0.1, ease: 'expo.out', scrollTrigger: trigger });
    gsap.from(q('.eyebrow, .portfolio__lede'), { y: 24, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: trigger });
  });

  return (
    <section id="portfolio" className="portfolio">
      <div className="portfolio__head section" ref={head}>
        <p className="eyebrow">Selected work</p>
        <h2 className="h1">
          <span className="line">
            <span>Portfolio</span>
          </span>
          <span className="line">
            <span className="accent">2026</span>
          </span>
        </h2>
        <p className="portfolio__lede">Click any design for a larger preview — use ← → to browse.</p>
      </div>
      <CategoryNav />
      <div className="portfolio__cats">
        {CATEGORIES.map((c) => (
          <CategorySection key={c.id} cat={c} onOpen={onOpen} />
        ))}
      </div>
    </section>
  );
}
