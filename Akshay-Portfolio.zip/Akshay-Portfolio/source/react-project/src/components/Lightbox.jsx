import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { startScroll, stopScroll } from '../lib/scroll.js';

const variants = {
  enter: (d) => ({ opacity: 0, x: 70 * d, scale: 0.95 }),
  center: { opacity: 1, x: 0, scale: 1 },
  exit: (d) => ({ opacity: 0, x: -70 * d, scale: 0.95 }),
};

// Large preview / mini case study. Keyboard: Esc, ← →. Touch: swipe.
export default function Lightbox({ items, index, onClose, onIndex }) {
  const item = items[index];
  const [dir, setDir] = useState(1);
  const [showPage, setShowPage] = useState(false);
  const closeRef = useRef(null);

  const go = useCallback(
    (d) => {
      setDir(d);
      setShowPage(false);
      onIndex((index + d + items.length) % items.length);
    },
    [index, items.length, onIndex],
  );

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, onClose]);

  useEffect(() => {
    stopScroll();
    closeRef.current?.focus();
    return () => startScroll();
  }, []);

  const stop = (e) => e.stopPropagation();
  const imgSrc = showPage ? item.page : item.src;

  return (
    <motion.div
      className="lb"
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35 }}
      onClick={onClose}
    >
      <div className="lb__top" onClick={stop}>
        <span className="lb__count">
          {String(index + 1).padStart(2, '0')} / {String(items.length).padStart(2, '0')}
        </span>
        <div className="lb__actions">
          <button type="button" className="lb__btn" onClick={() => setShowPage((v) => !v)} aria-pressed={showPage}>
            {showPage ? 'Design only' : 'Portfolio page'}
          </button>
          <a className="lb__btn" href={imgSrc} target="_blank" rel="noopener noreferrer">
            Open image
          </a>
          <button ref={closeRef} type="button" className="lb__btn lb__btn--close" onClick={onClose} aria-label="Close preview">
            Close ✕
          </button>
        </div>
      </div>

      <button type="button" className="lb__nav lb__nav--prev" onClick={(e) => (stop(e), go(-1))} aria-label="Previous design">
        ←
      </button>
      <button type="button" className="lb__nav lb__nav--next" onClick={(e) => (stop(e), go(1))} aria-label="Next design">
        →
      </button>

      <div className="lb__stage">
        <AnimatePresence mode="wait" custom={dir} initial={false}>
          <motion.figure
            key={item.id + (showPage ? '-page' : '')}
            className={`lb__fig${showPage ? ' is-page' : ''}`}
            custom={dir}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.25}
            onDragEnd={(_, info) => {
              if (info.offset.x < -90) go(1);
              else if (info.offset.x > 90) go(-1);
            }}
            onClick={stop}
          >
            <img src={imgSrc} alt={item.alt} draggable="false" />
          </motion.figure>
        </AnimatePresence>
      </div>

      <div className="lb__caption" onClick={stop}>
        <h3>{item.title}</h3>
        <p>
          {item.category}
          {item.tool && <> · {item.tool}</>}
          {item.client && <> · {item.client}</>}
        </p>
      </div>
    </motion.div>
  );
}
