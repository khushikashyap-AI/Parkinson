import { useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { JOBS, PROFILE } from '../data/data.js';
import { prefersReducedMotion } from '../lib/scroll.js';

gsap.registerPlugin(ScrollTrigger);

export default function Experience() {
  const root = useRef(null);

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(root);
      const head = { trigger: q('.exp__head')[0], start: 'top 80%', once: true };

      gsap.from(q('.exp__head .line > span'), { yPercent: 115, duration: 1.2, stagger: 0.1, ease: 'expo.out', scrollTrigger: head });
      gsap.from(q('.exp__head .eyebrow, .exp__sum'), { y: 24, autoAlpha: 0, duration: 1, stagger: 0.12, ease: 'expo.out', scrollTrigger: head });

      // The timeline line draws as you scroll through the list.
      gsap.fromTo(
        q('.tl__line-fill'),
        { scaleY: 0 },
        { scaleY: 1, ease: 'none', transformOrigin: 'top', scrollTrigger: { trigger: q('.tl')[0], start: 'top 70%', end: 'bottom 60%', scrub: true } },
      );

      q('.tl__item').forEach((item) => {
        const t = { trigger: item, start: 'top 80%', once: true };
        gsap
          .timeline({ scrollTrigger: t })
          .from(item.querySelector('.tl__dot'), { scale: 0, duration: 0.7, ease: 'back.out(2.4)' }, 0)
          .from(item.querySelectorAll('.tl__company .ch'), { yPercent: 115, duration: 1, stagger: 0.025, ease: 'expo.out' }, 0.1)
          .from(item.querySelectorAll('.tl__role, .tl__when, .tl__note'), { x: 40, autoAlpha: 0, duration: 0.9, stagger: 0.12, ease: 'expo.out' }, 0.3);
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="experience" className="section exp" ref={root}>
      <div className="exp__head">
        <p className="eyebrow">Experience</p>
        <h2 className="h1">
          <span className="line">
            <span>Work</span>
          </span>
          <span className="line">
            <span className="accent">experience</span>
          </span>
        </h2>
        <p className="exp__sum">
          {PROFILE.experienceYears} years of experience in graphic and marketing design.
        </p>
      </div>

      <ol className="tl">
        <span className="tl__line" aria-hidden="true">
          <span className="tl__line-fill" />
        </span>
        {JOBS.map((job, i) => (
          <li className="tl__item" key={job.company}>
            <span className="tl__dot" aria-hidden="true" />
            <span className="tl__no" aria-hidden="true">0{i + 1}</span>
            <div className="tl__body">
              <h3 className="tl__company" aria-label={job.company}>
                <span className="mask-line">
                  {job.company.split('').map((c, k) => (
                    <span className="ch" key={k} aria-hidden="true">
                      {c === ' ' ? ' ' : c}
                    </span>
                  ))}
                </span>
              </h3>
              <p className="tl__role">{job.role}</p>
              <p className="tl__when">{job.when}</p>
              {job.note && <span className="tl__note">{job.note}</span>}
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
