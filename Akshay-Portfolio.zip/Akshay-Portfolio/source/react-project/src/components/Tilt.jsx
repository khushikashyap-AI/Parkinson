import { motion, useMotionValue, useMotionTemplate, useSpring, useTransform } from 'framer-motion';

// Subtle 3D tilt that follows the pointer, plus a soft light that tracks the cursor.
// Framer Motion owns this element's transform; GSAP animates the wrappers around it.
export default function Tilt({ children, max = 7, scale = 1.03, className = '' }) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const spring = { stiffness: 220, damping: 22, mass: 0.6 };
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [max, -max]), spring);
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-max, max]), spring);
  const gx = useTransform(x, [-0.5, 0.5], [0, 100]);
  const gy = useTransform(y, [-0.5, 0.5], [0, 100]);
  const glow = useMotionTemplate`radial-gradient(circle at ${gx}% ${gy}%, rgba(90,160,255,0.22), transparent 55%)`;

  const onMove = (e) => {
    if (e.pointerType && e.pointerType !== 'mouse') return; // no tilt on touch
    const r = e.currentTarget.getBoundingClientRect();
    x.set((e.clientX - r.left) / r.width - 0.5);
    y.set((e.clientY - r.top) / r.height - 0.5);
  };
  const onLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      className={`tilt ${className}`}
      style={{ rotateX, rotateY, transformPerspective: 900 }}
      whileHover={{ scale }}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
    >
      {children}
      <motion.span className="tilt__glow" style={{ background: glow }} aria-hidden="true" />
    </motion.div>
  );
}
