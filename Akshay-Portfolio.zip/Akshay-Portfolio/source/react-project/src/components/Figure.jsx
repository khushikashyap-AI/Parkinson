import Tilt from './Tilt.jsx';

// One portfolio piece: tilt + clickable thumbnail (opens the lightbox) + caption.
// Structure is relied on by the GSAP animations in Portfolio.jsx:
//   .par  >  figure.reveal  >  (Tilt > button.piece > img) + figcaption.cap
export function Piece({ item, onOpen, max = 7, eager = false }) {
  return (
    <Tilt max={max}>
      <button type="button" className="piece" onClick={() => onOpen(item.idx)} aria-label={`Open ${item.title}`}>
        <img
          src={item.src}
          width={item.w}
          height={item.h}
          alt={item.alt}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          draggable="false"
        />
        <span className="piece__veil" aria-hidden="true">
          <span className="piece__cta">View</span>
        </span>
      </button>
    </Tilt>
  );
}

export default function Figure({ item, onOpen, max }) {
  return (
    <div className="par">
      <figure className="reveal">
        <Piece item={item} onOpen={onOpen} max={max} />
        <figcaption className="cap">
          <span>{item.title}</span>
          {item.client && <em>{item.client}</em>}
        </figcaption>
      </figure>
    </div>
  );
}
