import { useEffect, useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import Chars from './Chars.jsx';
import { PROFILE, PRELOAD } from '../data/data.js';
import { prefersReducedMotion } from '../lib/scroll.js';

// Drifting light particles (blue, with a few orange sparks) on a canvas.
function Particles() {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0;
    let h = 0;
    let raf = 0;
    let ps = [];

    const make = (anywhere) => ({
      x: Math.random() * w,
      y: anywhere ? Math.random() * h : h + 10,
      r: Math.random() * 1.6 + 0.4,
      v: Math.random() * 0.35 + 0.08,
      a: Math.random() * 0.6 + 0.2,
      orange: Math.random() < 0.14,
      ph: Math.random() * 6.28,
    });
    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ps = Array.from({ length: Math.round((w * h) / 14000) }, () => make(true));
    };
    const loop = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of ps) {
        p.y -= p.v;
        p.ph += 0.01;
        p.x += Math.sin(p.ph) * 0.15;
        if (p.y < -10) Object.assign(p, make(false));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.orange ? `rgba(255,138,61,${p.a})` : `rgba(120,170,255,${p.a})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    };
    resize();
    loop();
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);
  return <canvas ref={ref} className="intro__particles" aria-hidden="true" />;
}

export default function Intro({ onReveal, onDone }) {
  const root = useRef(null);
  const counter = useRef(null);
  const exitRef = useRef(null);

  useLayoutEffect(() => {
    const reduced = prefersReducedMotion();
    let cancelled = false;
    let exiting = false;
    let played = false;
    let preloaded = false;
    const timers = [];
    let ctx;

    const exit = () => {
      if (cancelled || exiting) return;
      exiting = true;
      ctx.add(() => {
        const q = gsap.utils.selector(root);
        gsap
          .timeline({ defaults: { ease: 'expo.inOut' }, onComplete: onDone })
          .to(q('.intro__content'), { y: -60, autoAlpha: 0, duration: 0.7, ease: 'power3.in' }, 0)
          .to(q('.intro__streak'), { autoAlpha: 0, duration: 0.4 }, 0)
          .add(() => onReveal(), 0.35)
          .to(root.current, { clipPath: 'inset(0% 0% 100% 0%)', duration: 1.3 }, 0.3);
      });
    };
    exitRef.current = exit;
    const maybeExit = () => {
      if (played && preloaded) exit();
    };

    // Preload the first images while the animation plays (never wait more than 5s).
    Promise.all(
      PRELOAD.map(
        (src) =>
          new Promise((resolve) => {
            const img = new Image();
            img.onload = img.onerror = resolve;
            img.src = src;
          }),
      ),
    ).then(() => {
      preloaded = true;
      if (!cancelled) maybeExit();
    });
    timers.push(
      setTimeout(() => {
        preloaded = true;
        maybeExit();
      }, 5000),
    );

    ctx = gsap.context(() => {
      const q = gsap.utils.selector(root);

      if (reduced) {
        played = true;
        timers.push(setTimeout(maybeExit, 700));
        return;
      }

      gsap.set(q('.intro__name .ch'), { yPercent: 115, rotateX: -80, autoAlpha: 0, transformOrigin: '50% 100%' });
      gsap.set(q('.intro__title'), { autoAlpha: 0, letterSpacing: '0.9em' });
      gsap.set(q('.intro__rule'), { autoAlpha: 0, scaleX: 0 });
      gsap.set(q('.intro__tag'), { autoAlpha: 0 });

      const tl = gsap.timeline({
        defaults: { ease: 'expo.out' },
        onUpdate: () => {
          if (counter.current) counter.current.textContent = String(Math.round(tl.progress() * 100)).padStart(3, '0');
        },
        onComplete: () => {
          played = true;
          maybeExit();
        },
      });
      tl.fromTo(q('.intro__streak'), { xPercent: -160 }, { xPercent: 160, duration: 2.4, stagger: 0.16, ease: 'power2.inOut' }, 0)
        .to(q('.intro__name .ch'), { yPercent: 0, rotateX: 0, autoAlpha: 1, duration: 1.3, stagger: 0.05 }, 0.35)
        .to(q('.intro__rule'), { autoAlpha: 1, scaleX: 1, duration: 1.2, ease: 'expo.inOut' }, 1.3)
        .to(q('.intro__title'), { autoAlpha: 1, letterSpacing: '0.34em', duration: 1.6 }, 1.45)
        .to(q('.intro__tag'), { autoAlpha: 1, duration: 1 }, 1.9)
        .to({}, { duration: 0.5 });
    }, root);

    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
      ctx.revert();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="intro" ref={root} role="status" aria-label="Loading portfolio">
      <Particles />
      <div className="intro__streaks" aria-hidden="true">
        {[8, 24, 41, 58, 73, 90].map((top, i) => (
          <span key={i} className={`intro__streak${i % 3 === 2 ? ' is-orange' : ''}`} style={{ top: `${top}%` }} />
        ))}
      </div>

      <div className="intro__content">
        <p className="intro__tag">{PROFILE.edition}</p>
        <h1 className="intro__name" aria-label={PROFILE.name}>
          <span className="mask-line">
            <Chars text="AKSHAY" />
          </span>
          <span className="mask-line">
            <Chars text="INGOLE" />
          </span>
        </h1>
        <span className="intro__rule" aria-hidden="true" />
        <p className="intro__title">{PROFILE.title}</p>
      </div>

      <div className="intro__foot">
        <span ref={counter} className="intro__count" aria-hidden="true">
          000
        </span>
        <button type="button" className="intro__skip" onClick={() => exitRef.current?.()}>
          Skip intro
        </button>
      </div>
    </div>
  );
}
