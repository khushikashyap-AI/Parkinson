import { useCallback, useEffect, useLayoutEffect, useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Intro from './components/Intro.jsx';
import Nav from './components/Nav.jsx';
import ScrollProgress from './components/ScrollProgress.jsx';
import Hero from './components/Hero.jsx';
import About from './components/About.jsx';
import Portfolio from './components/Portfolio.jsx';
import Experience from './components/Experience.jsx';
import Contact from './components/Contact.jsx';
import Lightbox from './components/Lightbox.jsx';
import { ALL_ITEMS, PROFILE } from './data/data.js';
import { destroySmoothScroll, initSmoothScroll, scrollToId, startScroll, stopScroll } from './lib/scroll.js';

export default function App() {
  const [ready, setReady] = useState(false); // intro is wiping away → start hero + nav entrances
  const [introDone, setIntroDone] = useState(false); // intro fully gone → unlock scrolling
  const [open, setOpen] = useState(null); // lightbox index (or null)

  // Smooth scrolling; the page stays locked while the intro plays.
  useLayoutEffect(() => {
    window.history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);
    initSmoothScroll();
    stopScroll();
    return destroySmoothScroll;
  }, []);

  useEffect(() => {
    if (!introDone) return;
    startScroll();
    ScrollTrigger.refresh();
  }, [introDone]);

  // Recalculate trigger positions once every image has loaded.
  useEffect(() => {
    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener('load', refresh);
    return () => window.removeEventListener('load', refresh);
  }, []);

  const closeLightbox = useCallback(() => setOpen(null), []);

  return (
    <>
      <a
        className="skip"
        href="#portfolio"
        onClick={(e) => {
          e.preventDefault();
          scrollToId('portfolio');
        }}
      >
        Skip to portfolio
      </a>
      <ScrollProgress />
      <Nav ready={ready} />

      <main>
        <Hero ready={ready} />
        <About />
        <Portfolio onOpen={setOpen} />
        <Experience />
        <Contact />
      </main>

      <footer className="footer">
        <span>© 2026 {PROFILE.name}</span>
        <button type="button" onClick={() => scrollToId('home')}>
          Back to top ↑
        </button>
      </footer>

      <AnimatePresence>
        {open !== null && <Lightbox items={ALL_ITEMS} index={open} onClose={closeLightbox} onIndex={setOpen} />}
      </AnimatePresence>

      {!introDone && <Intro onReveal={() => setReady(true)} onDone={() => setIntroDone(true)} />}
    </>
  );
}
