# Akshay Ingole — Animated Portfolio 2026

A cinematic, scroll-driven portfolio website built from your portfolio PDF.
**React + Vite · GSAP + ScrollTrigger · Framer Motion · Lenis smooth scroll · modern CSS.**

All artwork is taken from your PDF — nothing is redrawn or replaced. Each design was cropped
from the PDF's native page images at its original aspect ratio.

## Run it locally

Requires **Node.js 18+** (20 or 22 recommended).

```bash
cd portfolio
npm install
npm run dev        # → http://localhost:5173
```

Production build:

```bash
npm run build      # outputs to dist/
npm run preview    # serve the built site locally
```

`dist/` is a static site (relative paths), so you can drop it on Netlify, Vercel, GitHub Pages,
or any static host / sub-folder.

## What's in the site

| Section | Animation |
| --- | --- |
| **Intro** | Navy `#08162A` reveal: kinetic name typography, light streaks, particles, title tracking-in, then a cinematic wipe into the site. "Skip intro" button included. |
| **Home** | Name rises letter-by-letter; four of your designs float with mouse + scroll parallax. |
| **About** | Your quote on a torn-paper note (wipe + 3D turn), skills icons, stat count-up. |
| **Social media posts** | Scale-in with subtle 3D tilt (and cursor-following tilt on hover). |
| **Posters / Banners** | Masked reveal + zoom settle + parallax drift. |
| **Standees** | Vertical slides — alternating up / down, with counter-parallax. |
| **Brochures & flyers** | Scroll-scrubbed page-opening spreads (cover swings open to reveal both pages). |
| **T-shirts** | Product-style circular reveal with a soft spotlight and gentle float. |
| **Experience** | Timeline that draws as you scroll, staggered text reveals. |
| **Contact** | Animated typography, `mailto:` / `tel:` links, copy-email button. |

Interaction: hover tilt/zoom on every piece · click to open the **lightbox** (← → keys, swipe, Esc,
"Portfolio page" toggle shows the original PDF page, "Open image" opens the file) · sticky category
switcher · scroll progress bar · animated nav with mobile menu. `prefers-reduced-motion` is respected
(animations and smooth-scroll are switched off).

## Project structure

```
public/
  pages/           the 16 original PDF pages (1920×1080)
  work/crops/      each design, cropped from those pages (+ skills icon strip)
scripts/
  crop_panels.py   re-creates every crop and src/data/manifest.json (box coordinates live here)
src/
  data/data.js     ★ all text, categories, titles, clients and job history — edit content here
  components/      Intro, Nav, Hero, About, Portfolio, Experience, Contact, Lightbox, Tilt, …
  lib/scroll.js    Lenis smooth scroll wired to GSAP ScrollTrigger
  styles.css       design tokens (colours, fonts) + all layout
```

### Common edits

- **Colours / fonts:** the variables at the top of `src/styles.css` (`--bg`, `--blue`, `--orange`, …).
- **Text, contact details, job history:** `src/data/data.js`.
- **Replace a design with a higher-resolution original:** overwrite the matching file in
  `public/work/crops/` (e.g. `social-03.jpg`). Keep the same file name; if the aspect ratio changes,
  update its `w`/`h` in `src/data/manifest.json` so layout doesn't jump.
- **Add a piece:** add the image to `public/work/crops/`, add its entry to `manifest.json`, then add its
  name to the right category's `range(...)` in `data.js`.

## Notes about your content

- The PDF's pages are flattened 1920×1080 images, so each design can only be as sharp as it appears in
  the PDF. The site never upscales beyond that in the grid; the lightbox may enlarge small pieces. For
  maximum crispness, swap in your original exports (see above).
- Text is kept as written in the PDF, including the company name **"Omotech"** (the designs themselves
  say **OMOTEC**), the address spelling, and **"4.10+"** years. The PDF's closing slide reads
  "LAT'S WORK TOGETHER"; the site uses "Let's work together".
- Per-job dates are only shown where the PDF gives them (Omotech: since January 2026). ImpactGuru is
  "More than 3 years" and Wizfx Communication "6 months", exactly as stated.
- Clients (ImpactGuru / OMOTEC) are credited only where their logo appears in the design.
- The banner designs that show placeholder text ("Your Brand", "Lorem ipsum") are included because they
  are in your PDF — you may want to swap or drop those.
