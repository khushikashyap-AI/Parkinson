"""Builds the standalone, no-npm version: <out>/index.html + <out>/work/{crops,pages}."""
import json, os, shutil, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(ROOT, 'standalone')
tpl = open(os.path.join(ROOT, 'scripts', 'standalone.template.html'), encoding='utf-8').read()
css = open(os.path.join(ROOT, 'src', 'styles.css'), encoding='utf-8').read()
manifest = json.load(open(os.path.join(ROOT, 'src', 'data', 'manifest.json')))
html = tpl.replace('/*__CSS__*/', css).replace('/*__MANIFEST__*/', json.dumps(manifest))
if os.path.exists(OUT): shutil.rmtree(OUT)
os.makedirs(os.path.join(OUT, 'work'))
open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8').write(html)
shutil.copytree(os.path.join(ROOT, 'public', 'work', 'crops'), os.path.join(OUT, 'work', 'crops'))
shutil.copytree(os.path.join(ROOT, 'public', 'pages'), os.path.join(OUT, 'work', 'pages'))
print('built', OUT, round(len(html) / 1024), 'KB html')
