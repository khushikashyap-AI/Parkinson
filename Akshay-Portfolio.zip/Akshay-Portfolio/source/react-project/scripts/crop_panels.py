"""Crops each design panel out of the native 1920x1080 portfolio pages.
Boxes are in a 1456x819 reference space (how the pages were inspected) and scaled up."""
from PIL import Image
import os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PAGES = os.path.join(ROOT, 'public', 'pages')
OUT = os.path.join(ROOT, 'public', 'work')
S = 1920 / 1456
INSET = 2
# name: (page, x0, y0, x1, y1)
BOXES = {
 'social-01': (3, 17, 240, 518, 742),
 'social-02': (3, 558, 237, 981, 747),
 'social-03': (3, 1018, 237, 1427, 747),
 'social-04': (4, 20, 142, 447, 671),
 'social-05': (4, 459, 140, 989, 671),
 'social-06': (4, 1002, 138, 1437, 671),
 'social-07': (5, 58, 92, 703, 737),
 'social-08': (5, 717, 90, 1364, 735),
 'poster-01': (6, 28, 318, 472, 761),
 'poster-02': (6, 497, 310, 942, 769),
 'poster-03': (6, 967, 310, 1427, 765),
 'poster-04': (7, 8, 169, 453, 612),
 'poster-05': (7, 517, 169, 975, 612),
 'poster-06': (7, 1001, 166, 1413, 680),
 'banner-01': (8, 50, 184, 705, 441),
 'banner-02': (8, 740, 184, 1388, 441),
 'banner-03': (8, 48, 479, 697, 737),
 'banner-04': (8, 776, 457, 1389, 765),
 'standee-01': (9, 496, 30, 865, 768),
 'standee-02': (9, 957, 25, 1210, 784),
 'standee-03': (10, 452, 124, 769, 758),
 'standee-04': (10, 781, 127, 1097, 760),
 'standee-05': (10, 1104, 127, 1420, 758),
 'brochure-01': (11, 100, 281, 405, 737),
 'brochure-02': (11, 413, 281, 717, 737),
 'brochure-03': (11, 743, 272, 1071, 737),
 'brochure-04': (11, 1085, 271, 1414, 737),
 'flyer-01': (12, 215, 61, 705, 754),
 'flyer-02': (12, 777, 55, 1267, 748),
 'tee-01': (13, 117, 295, 581, 760),
 'tee-02': (13, 664, 77, 1347, 760),
 'tee-03': (14, 29, 205, 487, 662),
 'tee-04': (14, 506, 205, 964, 662),
 'tee-05': (14, 983, 205, 1427, 662),
 'extra-skills': (2, 868, 236, 1412, 322),
}
import json
manifest = {}
only = set(sys.argv[1:])
os.makedirs(os.path.join(OUT, 'crops'), exist_ok=True)
for name, (pg, x0, y0, x1, y1) in BOXES.items():
    if only and name not in only: continue
    im = Image.open(os.path.join(PAGES, f'page-{pg:02d}.jpg'))
    box = tuple(int(round(v * S)) for v in (x0 + INSET, y0 + INSET, x1 - INSET, y1 - INSET))
    c = im.crop(box)
    c.save(os.path.join(OUT, 'crops', f'{name}.jpg'), quality=95)
    manifest[name] = {'page': pg, 'w': c.size[0], 'h': c.size[1]}
    print(name, c.size)

if not only:
    os.makedirs(os.path.join(ROOT,'src','data'), exist_ok=True)
    json.dump(manifest, open(os.path.join(ROOT,'src','data','manifest.json'),'w'), indent=1)
