Akshay Ingole - Graphic Design Portfolio
index.html  = the finished website, ONE self-contained file. Double-click to open (online for fonts/animation libs).
source/     = build scripts (standalone-build, AI upscaler) and the React/Vite project (without images).
To get sharper images, replace the crops with your original design files and rebuild.
